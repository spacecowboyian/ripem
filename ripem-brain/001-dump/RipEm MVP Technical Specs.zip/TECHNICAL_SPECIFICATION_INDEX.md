# RipEm MVP Technical Specification
## Document Index & Executive Summary

**Generated**: April 9, 2025  
**Timeline**: 2-Month Phased Launch (Weeks 1-8)  
**Status**: Ready for Agent Implementation  

---

## Documents Included

This package contains 5 comprehensive technical specification documents:

### 1. **Core Architecture Overview** (`technical_spec_core_architecture.md`)
   - **Purpose**: High-level system design and phased launch plan
   - **Covers**: Architecture principles, phased timeline (Weeks 1-8), the "Car Buddy" AI personality, backend requirements, subscription model, success metrics
   - **For**: Technical leads, project managers, anyone needing overview
   - **Key Sections**: 
     - Phased Launch Timeline (onboarding, logging, social)
     - Car Buddy AI System Prompt
     - Voice → Transcription → AI Pipeline
     - Subscription Tiers (Free, Chat Pro, Shop)

### 2. **Onboarding Flow & Questionnaire** (`technical_spec_onboarding_flow.md`)
   - **Purpose**: Detailed onboarding experience design
   - **Covers**: 12-question questionnaire flow, UX philosophy, first AI response, success metrics, iteration points
   - **For**: iOS developers, product designers, QA
   - **Key Sections**:
     - Screen-by-screen questionnaire (welcome → car name → vision → summary)
     - Example first AI response (the "Dale moment")
     - Questionnaire data structure (JSON schema)
     - AI system prompt for onboarding
     - Edge cases and fallbacks

### 3. **Data Model & Database Schema** (`technical_spec_data_model.md`)
   - **Purpose**: Complete database design
   - **Covers**: All tables, fields, relationships, indexes, data flow diagrams, query patterns, storage estimates
   - **For**: Backend engineers, database architects
   - **Key Sections**:
     - 11 main tables (users, projects, log_entries, conversations, etc.)
     - Complete SQL schema
     - Data flow diagrams (onboarding, voice logging, Instagram sharing, discovery feed)
     - AI context retrieval pattern
     - Performance considerations and cost tracking

### 4. **REST API Specification** (`technical_spec_api.md`)
   - **Purpose**: Complete API contract for iOS/web apps
   - **Covers**: All endpoints, request/response examples, error handling, rate limiting, pagination
   - **For**: iOS developers, web developers, QA
   - **Key Sections**:
     - Auth endpoints (register, login, OAuth, refresh)
     - Garage & Project endpoints (create, read, update, delete)
     - Log Entry endpoints (voice logging pipeline)
     - AI Chat endpoints (async response pattern)
     - Instagram Share endpoints (preview, publish, metrics)
     - Discovery Feed endpoints (personalization, algorithm)
     - Subscription endpoints (upgrade, status)
     - User Profile endpoints
     - Complete error codes and status codes

### 5. **iOS App Architecture** (`technical_spec_ios_architecture.md`)
   - **Purpose**: Complete iOS implementation guide
   - **Covers**: SwiftUI/MVVM architecture, services layer, screen hierarchy, code examples, state management
   - **For**: iOS developers
   - **Key Sections**:
     - Architecture overview (UI → ViewModels → AppState → Services → APIs)
     - Core data models (User, Project, LogEntry, etc.)
     - App state management (Redux-style)
     - Screen-by-screen implementation (6 key screens)
     - Service implementations (APIService, AudioService, DatabaseService, SyncService)
     - Offline-first sync strategy
     - Testing and performance optimization

---

## Quick Start for Agents

### Phase 1: Onboarding (Weeks 1-2)

**Start here**: `technical_spec_onboarding_flow.md`

**What to build**:
1. iOS screens 1-12 (questionnaire flow)
2. Questionnaire data structure
3. First AI response generation (System prompt)
4. Database tables: `users`, `garages`, `projects`, `questionnaire_responses`
5. Backend endpoints: `/auth/register`, `/auth/login`, `/garage/create`, `/project/create`, `/ai/chat` (first response)

**Definition of Done**:
- User can answer 12 questions in under 10 minutes
- Onboarding completes with AI first response
- "Dale's a kickass name..." response is personalized and emotional
- 70%+ questionnaire completion rate in beta testing

---

### Phase 2: Voice Logging + AI (Weeks 3-4)

**Start here**: `technical_spec_core_architecture.md` → Voice Pipeline section + `technical_spec_ios_architecture.md` → RecordEntryView

**What to build**:
1. Voice recording UI (iOS)
2. Offline recording (local storage)
3. Whisper API integration (transcription)
4. Voice → Transcription → LLM → Response pipeline
5. Database tables: `log_entries`, `ai_conversations`, `ai_token_usage`
6. Backend endpoints: `/log/create`, `/ai/chat/{conversation_id}/response`, `/ai/chat/{project_id}/history`
7. Notification system (AI response ready)
8. Sync service (offline → online)

**Definition of Done**:
- User can record voice offline
- Recording syncs when online
- Transcription is accurate (Whisper API)
- AI response is contextual (reads garage brain)
- Notification shows when response is ready

---

### Phase 3: Instagram + Discovery (Weeks 5-8)

**Start here**: `technical_spec_core_architecture.md` → Instagram Integration + `technical_spec_api.md` → Instagram Share Endpoints

**What to build**:
1. AI caption generation for entries
2. Instagram OAuth integration
3. One-click Instagram publishing
4. Watermark rendering
5. Tracking URL generation
6. Discovery feed algorithm (V1)
7. Discovery UI (swipeable feed)
8. Subscription management (iOS In-App Purchase)
9. Database tables: `instagram_posts`, `discovery_feed`, `discovery_feed_items`, `subscriptions`
10. Backend endpoints: `/share/instagram/preview`, `/share/instagram/publish`, `/feed/discovery`, `/feed/subscribe`

**Definition of Done**:
- User can share entry to Instagram with one tap
- Caption is well-written (auto-generated)
- Watermark is visible and clickable
- Discovery feed shows relevant builds
- New users arrive via watermark links
- Subscription tier unlock works

---

## Architecture at a Glance

```
PHASE 1 (Weeks 1-2): Onboarding + Garage Brain
  ↓
PHASE 2 (Weeks 3-4): Voice Logging + AI Responses
  ↓
PHASE 3 (Weeks 5-8): Instagram Sharing + Discovery Feed
```

**Core Loop**:
1. User answers questionnaire → AI gets context
2. User logs voice entry → AI responds contextually
3. User shares to Instagram → Watermark drives discovery
4. Others see watermark → They join RipEm → Their garages become content → Network effects

---

## Key Numbers for MVP

| Metric | Target |
|--------|--------|
| **Onboarding completion rate** | 70%+ |
| **First log entry (Week 1)** | 50%+ |
| **Voice log per active user** | 3+ |
| **Sync reliability** | 99%+ |
| **Instagram share rate** | 1+ per user |
| **Watermark click-through rate** | 5-10% |
| **Discovery feed engagement** | 3+ subscriptions per user |
| **Retention (Day 7)** | 50%+ |

---

## Technology Stack Summary

| Component | Choice |
|-----------|--------|
| **iOS Frontend** | SwiftUI, Combine (Swift native) |
| **Web Frontend** | React/TypeScript (Phase 2) |
| **Backend API** | REST (framework TBD by agents) |
| **Database** | TBD (PostgreSQL recommended for AI context) |
| **Storage** | AWS S3 (photos, voice files) |
| **Voice Transcription** | Whisper API (OpenAI) |
| **LLM** | OpenRouter (all Claude calls) |
| **Instagram API** | OAuth + Graph API |
| **Authentication** | OAuth (Google, Apple) + Email/Password |
| **Hosting** | TBD (Vercel mentioned as standard) |
| **Offline-First** | SQLite local + sync service |

---

## Cost Breakdown (MVP, Estimated)

| Service | Monthly Cost (10K users) |
|---------|--------------------------|
| **LLM Tokens (OpenRouter)** | $500-1000 (free tier covers most) |
| **Whisper API** | $100-200 |
| **AWS S3** | $50-100 |
| **Database hosting** | $100-200 |
| **Server/API hosting** | $200-500 |
| **Apple Dev Account** | $99 (annual) |
| **Total** | $950-2100/month |

**Covered by**: Ads (free tier), subscriptions (paid tier), affiliate links

---

## Team Requirements for MVP

| Role | Capacity | Notes |
|------|----------|-------|
| **iOS Developer** | 1-2 FTE | SwiftUI, Swift, offline-first |
| **Backend Developer** | 1 FTE | API, database, LLM integration |
| **Product Manager** | 0.5 FTE | Prioritization, user feedback |
| **Designer** | 0.5 FTE | UI/UX for onboarding, screens |
| **QA** | 0.5 FTE | Testing, watermark tracking |

**Actual team for this project**: AI agents (self-managing, with oversight)

---

## Critical Success Factors

1. **Onboarding Emotional Hook** - First AI response must feel like a real friend (not generic)
2. **Voice-First UX** - Recording must be <5 seconds to start, <30 seconds to finish
3. **AI Context Quality** - Questionnaire data structure must be rich enough for smart responses
4. **Offline Reliability** - Sync failures will destroy trust
5. **Instagram Integration** - Watermark must drive real traffic, or growth loop fails
6. **Speed to Market** - 2 months to MVP is aggressive; phased delivery is essential

---

## Known Risks & Mitigation

| Risk | Impact | Mitigation |
|------|--------|-----------|
| **OpenRouter costs spiral** | High | Cap free tier token usage, move premium users to metered billing |
| **Whisper API latency** | Medium | Queue transcription jobs, show "transcribing..." state |
| **Instagram API rejection** | Medium | Apply early, use proper OAuth, follow rate limits |
| **Onboarding drop-off** | High | Test questionnaire length, iterate based on metrics |
| **Sync failures cause data loss** | Critical | Robust offline queue, backup to server daily, user warnings |
| **AI responses are generic** | High | Invest in system prompt tuning, test with real users, iterate |
| **MotorMia adds voice before launch** | Medium | Speed matters; focus on Instagram/content angle |

---

## How Agents Should Use These Docs

1. **Read the entire Core Architecture overview first** - Get the big picture
2. **Pick your phase** - Weeks 1-2, 3-4, or 5-8
3. **Find the corresponding document** - Onboarding, Data Model, API, iOS
4. **Build to spec** - These docs are contracts, not suggestions
5. **Test against success metrics** - Use the metrics section to validate
6. **Ask questions** - If something is unclear, flag it for the team

---

## Important Notes

- These specs are **detailed but flexible**. If agents find a better way to do something, that's fine—but document the change.
- **Token costs are real**. Track every LLM call, especially during testing.
- **Users will be ruthless**. The onboarding experience and first AI response will make or break adoption.
- **Phase the features intentionally**. Launching with everything at once is worse than launching with something great.

---

## Questions These Docs Answer

- ✅ **What should I build?** → See Phase 1-3 timeline
- ✅ **How should the AI behave?** → See Car Buddy system prompt + onboarding responses
- ✅ **What tables do I need?** → See Data Model schema
- ✅ **What API endpoints do I build?** → See API Specification
- ✅ **How do I handle offline?** → See iOS Architecture + SyncService
- ✅ **How do I measure success?** → See Success Metrics section
- ✅ **What's the phased delivery plan?** → See Phased Launch Timeline

---

## Next Steps After Implementation

1. **Week 4**: Beta launch to 100 internal testers (TestFlight)
2. **Week 5-6**: Iterate based on feedback (especially onboarding drop-off, AI response quality)
3. **Week 7-8**: Public App Store launch
4. **Week 9+**: Monitor metrics, scale, prepare Phase 2 features (real-time chat, video generation, web app)

---

## Document Maintenance

These specs should be updated when:
- **Discovery findings change** (e.g., MotorMia launches a feature we missed)
- **User feedback contradicts assumptions** (e.g., questionnaire too long)
- **Technology choices change** (e.g., database switch)
- **Phase timelines slip** (update expected completion dates)

---

**Good luck. Build something people love. 🚗**

