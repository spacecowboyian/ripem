# RipEm MVP: iOS App Architecture
## SwiftUI Implementation Guide

---

## Overview

This document outlines the iOS app architecture for RipEm MVP. The app is built with:
- **Language**: Swift
- **Framework**: SwiftUI + Combine
- **Minimum iOS**: 15.0
- **Architecture Pattern**: MVVM + Redux-style state management
- **Offline-First**: Local SQLite database + CloudKit sync

---

## Architecture Overview

```
┌─────────────────────────────────────┐
│         User Interface (SwiftUI)    │
│  ┌─────────────────────────────────┐│
│  │  Onboarding Flow                ││
│  │  Main App                       ││
│  │  Discovery Feed                 ││
│  │  Settings                       ││
│  └─────────────────────────────────┘│
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│    View Models (MVVM)               │
│  ┌─────────────────────────────────┐│
│  │  OnboardingViewModel            ││
│  │  ProjectViewModel               ││
│  │  LogEntryViewModel              ││
│  │  AIViewModel                    ││
│  │  DiscoveryFeedViewModel         ││
│  └─────────────────────────────────┘│
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│    App State (Redux-like)           │
│  ┌─────────────────────────────────┐│
│  │  AppState                       ││
│  │  - User                         ││
│  │  - Garage                       ││
│  │  - Projects                     ││
│  │  - LogEntries                   ││
│  │  - Conversations                ││
│  │  - DiscoveryFeed                ││
│  └─────────────────────────────────┘│
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│    Services Layer                   │
│  ┌─────────────────────────────────┐│
│  │  APIService (REST calls)        ││
│  │  AudioService (voice recording) ││
│  │  DatabaseService (local SQLite) ││
│  │  SyncService (offline sync)     ││
│  │  StorageService (S3 upload)     ││
│  │  LocationService (location)     ││
│  └─────────────────────────────────┘│
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│    External APIs                    │
│  ┌─────────────────────────────────┐│
│  │  RipEm Backend API              ││
│  │  Whisper API (OpenAI)           ││
│  │  Instagram API                  ││
│  │  Apple OAuth                    ││
│  │  AWS S3                         ││
│  └─────────────────────────────────┘│
└─────────────────────────────────────┘
```

---

## Core Data Models (Swift)

### User & Auth

```swift
struct User: Codable, Identifiable {
  let id: String
  let email: String
  let displayName: String
  let avatarURL: URL?
  let authToken: String
  let refreshToken: String
  var tokenExpiresAt: Date
  
  var isTokenExpired: Bool {
    Date() > tokenExpiresAt
  }
}

struct AuthState {
  var user: User?
  var isAuthenticated: Bool { user != nil }
  var isLoading: Bool = false
  var error: String?
}
```

### Project & Garage

```swift
struct Garage: Codable, Identifiable {
  let id: String
  let userId: String
  let name: String
  let description: String?
  var projects: [Project] = []
  let createdAt: Date
}

struct Project: Codable, Identifiable {
  let id: String
  let garageId: String
  
  // Car Basics
  let year: Int
  let make: String
  let model: String
  let name: String // "Dale"
  
  // Story & Vision
  let originStory: String?
  let vision: [String] // ["track_car"]
  let visionDetail: String?
  
  // Calibration
  let skillLevel: SkillLevel
  enum SkillLevel: String, Codable {
    case novice, intermediate, advanced, professional
  }
  
  // Budget & Timeline
  let budgetAmount: Decimal
  let timelineMonths: Int
  let timelineStartDate: Date
  
  // Current State
  let workCompleted: String?
  let primaryFocus: String?
  
  // Metadata
  var logEntries: [LogEntry] = []
  var goals: [Goal] = []
  let isPublic: Bool
  let createdAt: Date
  let updatedAt: Date
}
```

### Log Entry

```swift
struct LogEntry: Codable, Identifiable {
  let id: String
  let projectId: String
  
  // Voice & Transcription
  let voiceRecordingURL: URL?
  let voiceDuration: TimeInterval
  let transcript: String
  
  // Metadata
  let title: String?
  let summary: String?
  
  // AI Response
  let aiResponse: String
  
  // Photos
  var photoURLs: [URL] = []
  
  // Status
  let isPublic: Bool
  var isShared: Bool
  var likes: Int = 0
  
  // Timestamps
  let createdAt: Date
  let updatedAt: Date
  
  // Local tracking
  var syncStatus: SyncStatus = .pending
  enum SyncStatus: String, Codable {
    case pending, syncing, synced, failed
  }
}
```

---

## App State Management

```swift
@MainActor
class AppStore: ObservableObject {
  @Published var authState: AuthState = .init()
  @Published var garage: Garage?
  @Published var selectedProject: Project?
  @Published var logEntries: [LogEntry] = []
  @Published var conversations: [Conversation] = []
  @Published var discoveryFeed: [DiscoveryItem] = []
  @Published var syncStatus: SyncStatus = .idle
  
  enum SyncStatus {
    case idle
    case syncing
    case error(String)
    case paused(reason: String)
  }
  
  // MARK: - Actions
  
  func login(email: String, password: String) async {
    // Dispatch to APIService, update authState
  }
  
  func createProject(from questionnaire: QuestionnaireData) async {
    // Create project, get AI first response, update garage
  }
  
  func createLogEntry(transcript: String, photos: [UIImage], projectId: String) async {
    // Add to local db, sync to server, get AI response
  }
  
  func shareToInstagram(logEntryId: String) async {
    // Get caption, generate preview, open Instagram share sheet
  }
  
  func loadDiscoveryFeed() async {
    // Fetch personalized feed, update discoveryFeed
  }
}
```

---

## Screen Hierarchy

### Phase 1: Onboarding (Weeks 1-2)

```
TabBar
├── Onboarding (when new user)
│   ├── Welcome Screen
│   ├── Question 1-12 (questionnaire flow)
│   └── AI First Response Screen (loading + response)
└── Main App (after onboarding complete)
```

### Phase 2: Main App (Weeks 3-4+)

```
TabBar
├── Garage Tab
│   ├── Garage Summary (projects list)
│   ├── Project Detail
│   │   ├── Project Overview
│   │   ├── Log Entries (list)
│   │   ├── AI Chat
│   │   └── Goals
│   └── Record New Entry (voice)
│
├── Discovery Tab
│   ├── Discovery Feed (scrollable)
│   └── Subscriptions (people I follow)
│
└── Settings Tab
    ├── Profile
    ├── Preferences
    └── Subscription
```

---

## Key Screens

### Screen 1: Welcome / Auth

```swift
struct AuthView: View {
  @StateObject var viewModel: AuthViewModel
  @State var email: String = ""
  @State var password: String = ""
  
  var body: some View {
    NavigationStack {
      VStack(spacing: 20) {
        Text("Welcome to RipEm")
          .font(.title)
        
        TextField("Email", text: $email)
          .textFieldStyle(.roundedBorder)
        
        SecureField("Password", text: $password)
          .textFieldStyle(.roundedBorder)
        
        Button(action: { Task { await viewModel.login(email, password) } }) {
          Text("Login")
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        
        // OAuth buttons
        Button(action: { Task { await viewModel.loginWithGoogle() } }) {
          HStack {
            Image("google-logo")
            Text("Sign in with Google")
          }
        }
        .buttonStyle(.bordered)
        
        NavigationLink("Create Account", destination: SignUpView())
      }
      .padding()
    }
  }
}
```

### Screen 2: Onboarding Questionnaire

```swift
struct OnboardingQuestionView: View {
  @StateObject var viewModel: OnboardingViewModel
  @State var currentQuestion: Int = 0
  
  var body: some View {
    ZStack {
      VStack {
        ProgressView(value: Double(currentQuestion) / Double(viewModel.questions.count))
          .padding()
        
        TabView(selection: $currentQuestion) {
          ForEach(viewModel.questions.indices, id: \.self) { index in
            QuestionCard(
              question: viewModel.questions[index],
              response: $viewModel.responses[index]
            )
            .tag(index)
          }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        
        HStack {
          Button("Back") { currentQuestion -= 1 }
            .disabled(currentQuestion == 0)
          
          Spacer()
          
          if currentQuestion < viewModel.questions.count - 1 {
            Button("Next") { currentQuestion += 1 }
          } else {
            Button("Complete", action: {
              Task { await viewModel.submitQuestionnaire() }
            })
          }
        }
        .padding()
      }
      
      if viewModel.isSubmitting {
        VStack {
          ProgressView()
          Text("Building your AI buddy...")
        }
        .padding()
        .background(Color.black.opacity(0.3))
      }
    }
  }
}
```

### Screen 3: Garage (Project List)

```swift
struct GarageView: View {
  @EnvironmentObject var store: AppStore
  @State var showNewProject = false
  
  var body: some View {
    NavigationStack {
      VStack {
        if let garage = store.garage {
          List {
            ForEach(garage.projects) { project in
              NavigationLink(destination: ProjectDetailView(project: project)) {
                ProjectRow(project: project)
              }
            }
          }
        }
      }
      .navigationTitle("My Garage")
      .toolbar {
        Button(action: { showNewProject = true }) {
          Image(systemName: "plus.circle.fill")
        }
      }
    }
  }
}

struct ProjectRow: View {
  let project: Project
  
  var body: some View {
    VStack(alignment: .leading) {
      HStack {
        VStack(alignment: .leading) {
          Text(project.name)
            .font(.headline)
          Text("\(project.year) \(project.make) \(project.model)")
            .font(.caption)
            .foregroundColor(.secondary)
        }
        
        Spacer()
        
        VStack(alignment: .trailing) {
          Text("\(project.logEntries.count)")
            .font(.caption)
          Text("entries")
            .font(.caption2)
            .foregroundColor(.secondary)
        }
      }
    }
  }
}
```

### Screen 4: Record Voice Entry

```swift
struct RecordEntryView: View {
  @StateObject var viewModel: LogEntryViewModel
  @State var isRecording = false
  @State var recordingTime: TimeInterval = 0
  @State var selectedPhotos: [UIImage] = []
  
  var body: some View {
    NavigationStack {
      VStack(spacing: 20) {
        Text("Tell me about your progress on \(viewModel.project.name)")
          .font(.headline)
        
        ZStack {
          Circle()
            .stroke(Color.blue, lineWidth: 2)
          
          Button(action: {
            if isRecording {
              viewModel.stopRecording()
              isRecording = false
            } else {
              viewModel.startRecording()
              isRecording = true
            }
          }) {
            Image(systemName: isRecording ? "stop.circle.fill" : "record.circle")
              .font(.system(size: 60))
              .foregroundColor(isRecording ? .red : .blue)
          }
        }
        .frame(height: 150)
        
        if isRecording {
          Text(formatTime(recordingTime))
            .font(.title2)
            .onReceive(Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()) { _ in
              recordingTime += 0.1
            }
        }
        
        // Photos selector
        if selectedPhotos.isEmpty {
          Button(action: { /* show photo picker */ }) {
            Label("Add Photos (Optional)", systemImage: "photo.badge.plus")
          }
          .buttonStyle(.bordered)
        } else {
          ScrollView(.horizontal) {
            HStack {
              ForEach(selectedPhotos.indices, id: \.self) { index in
                Image(uiImage: selectedPhotos[index])
                  .resizable()
                  .scaledToFill()
                  .frame(width: 80, height: 80)
                  .cornerRadius(8)
              }
            }
          }
        }
        
        Spacer()
        
        if isRecording {
          Button("Cancel", role: .cancel) {
            viewModel.cancelRecording()
            isRecording = false
          }
          .buttonStyle(.bordered)
        } else {
          Button(action: {
            Task { await viewModel.submitEntry(photos: selectedPhotos) }
          }) {
            Text("Save Entry")
              .frame(maxWidth: .infinity)
          }
          .buttonStyle(.borderedProminent)
        }
      }
      .padding()
    }
  }
}
```

### Screen 5: Project AI Chat

```swift
struct AIAssistantView: View {
  @StateObject var viewModel: AIViewModel
  @State var userMessage: String = ""
  
  var body: some View {
    VStack {
      List(viewModel.messages) { message in
        HStack(alignment: .top) {
          if message.role == .user {
            Spacer()
          }
          
          VStack(alignment: message.role == .user ? .trailing : .leading) {
            Text(message.content)
              .padding(12)
              .background(message.role == .user ? Color.blue : Color.gray.opacity(0.2))
              .foregroundColor(message.role == .user ? .white : .black)
              .cornerRadius(8)
            
            Text(message.timestamp, style: .time)
              .font(.caption2)
              .foregroundColor(.secondary)
          }
          
          if message.role == .assistant {
            Spacer()
          }
        }
      }
      
      HStack {
        TextField("Ask your buddy...", text: $userMessage)
          .textFieldStyle(.roundedBorder)
        
        Button(action: {
          Task { await viewModel.sendMessage(userMessage) }
          userMessage = ""
        }) {
          Image(systemName: "paperplane.fill")
        }
        .disabled(userMessage.isEmpty)
      }
      .padding()
    }
    .navigationTitle(viewModel.project.name)
  }
}
```

### Screen 6: Discovery Feed

```swift
struct DiscoveryFeedView: View {
  @EnvironmentObject var store: AppStore
  @State var selectedIndex = 0
  
  var body: some View {
    NavigationStack {
      ZStack {
        TabView(selection: $selectedIndex) {
          ForEach(store.discoveryFeed.indices, id: \.self) { index in
            FeedCardView(item: store.discoveryFeed[index])
              .tag(index)
          }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        
        VStack {
          HStack {
            Button(action: { store.discoveryFeed[selectedIndex].isLiked.toggle() }) {
              Image(systemName: store.discoveryFeed[selectedIndex].isLiked ? "heart.fill" : "heart")
            }
            
            Spacer()
            
            Button(action: { /* share action */ }) {
              Image(systemName: "square.and.arrow.up")
            }
          }
          .padding()
          
          Spacer()
        }
      }
      .navigationTitle("Discover")
    }
  }
}

struct FeedCardView: View {
  let item: DiscoveryItem
  
  var body: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        VStack(alignment: .leading) {
          Text(item.carName)
            .font(.headline)
          Text("\(item.year) \(item.make) \(item.model)")
            .font(.caption)
        }
        
        Spacer()
        
        if let avatarURL = item.userAvatarURL {
          AsyncImage(url: avatarURL) { image in
            image.resizable()
              .scaledToFill()
              .frame(width: 40, height: 40)
              .clipShape(Circle())
          } placeholder: {
            Circle()
              .fill(Color.gray.opacity(0.3))
              .frame(width: 40, height: 40)
          }
        }
      }
      
      Text(item.transcriptPreview)
        .lineLimit(3)
      
      HStack {
        Label("\(item.likes)", systemImage: "heart")
        Spacer()
        Button(action: { /* subscribe */ }) {
          Text("Follow")
        }
      }
      .font(.caption)
    }
    .padding()
    .background(Color(.systemBackground))
  }
}
```

---

## Service Layer

### APIService

```swift
class APIService {
  private let baseURL = URL(string: "https://api.ripem.app/v1")!
  private var authToken: String?
  
  func login(email: String, password: String) async throws -> User {
    let payload = ["email": email, "password": password]
    let request = buildRequest(method: "POST", endpoint: "/auth/login", body: payload)
    let (data, response) = try await URLSession.shared.data(for: request)
    
    guard (response as? HTTPURLResponse)?.statusCode == 200 else {
      throw APIError.unauthorized
    }
    
    let decoded = try JSONDecoder().decode(LoginResponse.self, from: data)
    authToken = decoded.authToken
    return decoded.user
  }
  
  func createLogEntry(
    projectId: String,
    voiceURL: URL,
    photos: [UIImage]
  ) async throws -> LogEntry {
    var request = buildMultipartRequest(
      method: "POST",
      endpoint: "/log/create"
    )
    
    // Append voice file
    try append(file: voiceURL, named: "voice_file", to: &request)
    
    // Append photos
    for (index, photo) in photos.enumerated() {
      if let jpegData = photo.jpegData(compressionQuality: 0.8) {
        try append(data: jpegData, named: "photos", to: &request)
      }
    }
    
    let (data, response) = try await URLSession.shared.data(for: request)
    
    guard (response as? HTTPURLResponse)?.statusCode == 201 else {
      throw APIError.serverError
    }
    
    return try JSONDecoder().decode(LogEntry.self, from: data)
  }
}
```

### AudioService

```swift
class AudioService: NSObject, AVAudioRecorderDelegate {
  private var audioRecorder: AVAudioRecorder?
  private var recordingURL: URL?
  @Published var isRecording = false
  @Published var recordingTime: TimeInterval = 0
  
  func startRecording() throws {
    let audioSession = AVAudioSession.sharedInstance()
    try audioSession.setCategory(.record, mode: .default)
    try audioSession.setActive(true)
    
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    recordingURL = documentsPath.appendingPathComponent("recording-\(UUID().uuidString).m4a")
    
    let settings: [String: Any] = [
      AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
      AVSampleRateKey: 16000.0,
      AVNumberOfChannelsKey: 1
    ]
    
    audioRecorder = try AVAudioRecorder(url: recordingURL!, settings: settings)
    audioRecorder?.delegate = self
    audioRecorder?.record()
    
    isRecording = true
  }
  
  func stopRecording() throws -> URL {
    audioRecorder?.stop()
    isRecording = false
    
    guard let url = recordingURL else {
      throw AudioError.noRecording
    }
    
    return url
  }
}
```

### DatabaseService (Local SQLite)

```swift
class DatabaseService {
  private let db: Connection
  
  init() throws {
    let path = NSSearchPathForDirectoriesInDomains(
      .documentDirectory, .userDomainMask, true
    )[0]
    db = try Connection("\(path)/ripem.db")
  }
  
  func saveLogEntry(_ entry: LogEntry) throws {
    let logEntryTable = Table("log_entries")
    
    try db.run(logEntryTable.insert(
      Expression<String>("id") <- entry.id,
      Expression<String>("project_id") <- entry.projectId,
      Expression<String>("transcript") <- entry.transcript,
      Expression<String>("ai_response") <- entry.aiResponse,
      Expression<String>("sync_status") <- "pending",
      Expression<Date>("created_at") <- entry.createdAt
    ))
  }
  
  func getPendingEntries() throws -> [LogEntry] {
    let logEntryTable = Table("log_entries")
    let entries = try db.prepare(logEntryTable.filter(
      Expression<String>("sync_status") == "pending"
    ))
    
    return try entries.map { row in
      LogEntry(
        id: try row.get(Expression<String>("id")),
        projectId: try row.get(Expression<String>("project_id")),
        transcript: try row.get(Expression<String>("transcript")),
        aiResponse: try row.get(Expression<String>("ai_response")),
        createdAt: try row.get(Expression<Date>("created_at"))
      )
    }
  }
}
```

### SyncService (Offline-First)

```swift
class SyncService {
  @Published var syncStatus: SyncStatus = .idle
  private let apiService: APIService
  private let databaseService: DatabaseService
  private let reachability = try? Reachability()
  
  func startSync() {
    reachability?.whenReachable = { [weak self] _ in
      self?.syncPendingEntries()
    }
    
    try? reachability?.startNotifier()
  }
  
  private func syncPendingEntries() {
    Task {
      do {
        let pending = try databaseService.getPendingEntries()
        
        for entry in pending {
          let synced = try await apiService.syncLogEntry(entry)
          try databaseService.updateSyncStatus(entry.id, status: "synced")
        }
        
        syncStatus = .idle
      } catch {
        syncStatus = .error(error.localizedDescription)
      }
    }
  }
}
```

---

## State Flow Example: Recording & Syncing

```
User taps "Record"
    ↓
AudioService.startRecording()
    ↓
User speaks for 45 seconds
    ↓
User taps "Stop"
    ↓
AudioService.stopRecording() → returns local file URL
    ↓
LogEntryViewModel creates LogEntry object (syncStatus: .pending)
    ↓
DatabaseService.saveLogEntry() → saves to local SQLite
    ↓
App shows "Recording saved locally"
    ↓
[User is offline, app waits]
    ↓
[User goes online]
    ↓
Reachability notifies SyncService
    ↓
SyncService.syncPendingEntries()
    ↓
APIService.createLogEntry(voice file + photos)
    ↓
Whisper transcribes voice → AI responds
    ↓
Response comes back to app
    ↓
DatabaseService.updateLogEntry(response) + updateSyncStatus: .synced
    ↓
AppStore.logEntries updated
    ↓
UI shows AI response
    ↓
User sees notification: "Your buddy has responded"
```

---

## Testing Strategy

- **Unit Tests**: Services (APIService, AudioService, DatabaseService)
- **Integration Tests**: ViewModel → Service flows
- **UI Tests**: Onboarding flow, recording, sharing

---

## Performance Optimization

1. **Lazy Loading**: Discovery feed paginated, not all at once
2. **Image Caching**: AsyncImage with URLCache
3. **Database Indexing**: Indexes on frequently queried fields
4. **Offline-First**: Minimize API calls, batch sync
5. **Memory Management**: Careful with @Published vars, use weak references in closures

---

## Build & Deployment

- **Build System**: Xcode 15+
- **Provisioning**: Apple Developer Team
- **TestFlight**: Beta distribution in Week 4
- **App Store**: Launch after Week 8

