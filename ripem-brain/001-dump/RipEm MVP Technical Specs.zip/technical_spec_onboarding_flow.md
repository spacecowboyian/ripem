# RipEm MVP: Onboarding Flow & Questionnaire
## The "Car Buddy First Meeting" Design

---

## Overview

The onboarding questionnaire is the heart of RipEm's differentiation. It's not a form dump. It's a conversation where the AI gets to know the user and their project instantly.

When a user opens RipEm for the first time, they should feel: **"This app understands me."**

---

## Onboarding Goals

1. **Data Capture**: Gather enough context for AI to be immediately useful (garage brain)
2. **Relationship Building**: Make user feel heard and understood
3. **Excitement Generation**: User leaves thinking "This is different from ChatGPT"
4. **Habit Formation**: User wants to come back and log more about their project

---

## Questionnaire Design Philosophy

**Rule 1: Make it a conversation, not a form**
- Questions appear one-by-one, not all at once
- AI can react to previous answers
- User feels like they're talking to someone

**Rule 2: Capture story, not just specs**
- Don't ask "What year is your car?" before "What's your story?"
- Stories create emotional investment
- Stories are what the AI uses to build relationship

**Rule 3: Calibrate to user skill level**
- Early questions determine follow-up questions
- Novice gets different questions than advanced builder
- AI adjusts personality based on this

**Rule 4: Keep it under 10 minutes**
- Test with ~12-15 questions
- Shorter = higher completion rate
- Can always add more later

---

## Questionnaire Flow (iOS UX)

### Screen 1: Welcome

**Visual**: App logo, brief headline

**Text**: "Welcome to RipEm. Let's talk about your car project. I'm your AI garage buddy. I'll get to know your project, and then I'm here to help you build something amazing."

**CTA**: "Let's go" button

---

### Screen 2: Car Basics (The Foundation)

**Question**: "What car are you building?"

**Input Type**: Multi-select dropdown + text field
- Dropdown: Year (1960-2030)
- Dropdown: Make (alphabetical, searchable)
- Dropdown: Model (filtered by make/year)

**Why This Order**: Establishes the project before we get emotional

**After Input**: "Nice. A 1972 Toyota Celica. That's a classic."

---

### Screen 3: The Story (Emotional Connection)

**Question**: "Where did you get this car? What's the story?"

**Input Type**: Free text (encourage ~50-100 words, but not required)

**Placeholder**: "Did you restore it? Find it in a barn? Inherit it? Trade for it? Tell me the story."

**Why This Screen**: 
- Gets the "Dale" moment (named after original owner)
- Shows the AI cares about the *why*, not just the *what*
- User feels understood

**AI Reaction** (after user types): "Oh nice, you got it from Dale. The original owner. That's cool. Let's add that to the history."

---

### Screen 4: The Vision (What Are We Building?)

**Question**: "What's your vision for this car? What do you want to make of it?"

**Input Type**: Button choice (can select multiple)
- Track car
- Street/daily driver
- Restoration/show car
- Custom build/art project
- Restomod
- Off-road/adventure

**Additional**: Free text (why? what's the goal?)

**Why This Screen**:
- Determines AI's recommendations later (track car = different advice than restoration)
- Qualifies user motivation
- "Track car" → AI suggests motor swaps; "Restoration" → AI suggests paint/interior

**AI Reaction**: "Track car. Okay, so you're thinking performance and handling. That's a solid goal for a Celica."

---

### Screen 5: Skill Level (Calibration)

**Question**: "How much mechanical experience do you have?"

**Input Type**: Button choice
- Never turned a wrench (learning my first car)
- Some experience (changed oil, basic maintenance)
- Intermediate (replaced major components, understand systems)
- Advanced (engine swaps, rebuilds, custom fab)
- Professional (shop experience, trained mechanic)

**Why This Screen**:
- AI adjusts tone and complexity based on answer
- Novice gets hand-held steps; Advanced gets "just grab these parts"
- Critical for trust (user doesn't feel talked down to or confused)

**AI Reaction** (example for "Intermediate"): "Got it. You've got mechanical chops. I won't baby you, but I'll explain what's happening under the hood."

---

### Screen 6: Timeline & Budget (Reality Check)

**Question**: "What's your timeline and budget for this project?"

**Input Type**: Two sliders or text inputs
- Budget: $1K to $50K (or custom)
- Timeline: 3 months to 5 years

**Why This Screen**:
- AI knows if they're dreaming big ($50K LS swap in 3 months) or being realistic
- Sets expectations for recommendations ("Here's what's doable in your budget/timeframe")
- Prevents user frustration later

**AI Reaction**: "Okay, $5K over 2 years. That's smart. We'll focus on high-impact mods that fit that budget."

---

### Screen 7: What's Already Done (History)

**Question**: "What work have you already done on this car?"

**Input Type**: Free text (encourage user to list past modifications/repairs)

**Placeholder**: "Oil change, new water pump, new brakes, exhaust, seats, etc. Just list what's been done so far."

**Why This Screen**:
- Garage brain knows the *current state*
- AI doesn't suggest things already done
- Shows user progression (visual commitment to the project)

**AI Reaction**: "Water pump and fluids. Okay, so you've tackled cooling and maintenance. Good foundation."

---

### Screen 8: Name Your Car (Ritual)

**Question**: "Does your car have a name? What do you call it?"

**Input Type**: Free text (optional, but encourage it)

**Placeholder**: "Some people name their cars (Dale, The Beast, Project X, etc.). Yours?"

**Why This Screen**:
- **This is the emotional peak of onboarding**
- Named cars = deeper investment
- AI uses the name constantly ("How's Dale running?")
- Creates micro-habit of checking in on their car

**AI Reaction**: "Dale. That's perfect. So Dale's the star of this build. Got it."

---

### Screen 9: What's Your Jam? (AI Probe)

**Question**: "What are you most excited about for this project?"

**Input Type**: Free text

**Placeholder**: "Motor swap? New interior? Paint? Track day capability? What gets you excited about working on Dale?"

**Why This Screen**:
- Determines what the AI should prioritize talking about
- Sets the conversational tone for future interactions
- Shows user priorities

**AI Reaction**: "Motor swap. Yeah, that makes sense for a track car. More power is always fun. Let's dig into that."

---

### Screen 10: Questions for the AI (Kickstart)

**Question**: "Anything you want to ask me about your project right now?"

**Input Type**: Free text (optional)

**Placeholder**: "Motor swap options? Suspension? Budget breakdown? Anything on your mind?"

**Why This Screen**:
- User gets to control first AI interaction
- May surface concerns or ideas
- Sets them up for immediate conversation

**If Blank**: Skip to next screen

---

### Screen 11: Privacy Setting

**Question**: "How do you want to share your project?"

**Input Type**: Button choice
- Public (share on discovery feed, others can see)
- Private (just for me, no sharing)

**Default**: Public

**Why This Screen**:
- Sets expectations about watermarking/sharing
- Emphasizes social features
- Respects user preference

**AI Reaction**: "Public it is. Other builders will get to see Dale's journey."

---

### Screen 12: Summary & First AI Response

**Visual**: "Building Dale's profile... one moment"

**What Happens**:
1. Questionnaire data sent to backend
2. Data stored in `projects` table
3. Data sent to LLM with system prompt
4. AI generates personalized first response

**Screen Shows**:
- Summary of car (1972 Celica, Track Car, $5K/2yr)
- AI's first response (the magic moment)

**Example Response**:

> "Dale's a kickass name. So the original owner was Dale? That's sick, I'm adding that to the history.
>
> Okay, so you've got a classic Celica track car project. 1972 is the perfect year for this—solid platform. Based on what you've shared, you've got mechanical chops (water pump + fluids = you know how to work). Here's what I'm thinking:
>
> With a $5K budget over 2 years and track car ambitions, power is going to be your limiting factor. The stock 18R-C motor is... not a monster. There are some killer motor swap options for a 72 Celica that people have done successfully:
>
> - 4A-GE (popular, ~180hp, tunable)
> - 20V Blacktop (rarer, but 200+hp)
> - 2ZZ-GE (modern, reliable, ~180hp)
>
> Have you ever looked into swaps? What's your thinking—are you trying to keep it period-correct, or are you willing to go with something modern? Either way, let's make this thing a real monster. I'm here to help you figure it out."

**CTA**: "Got it. Let me explore..." (button to main app)

---

## Questionnaire Data Structure (Backend)

```json
{
  "project_id": "proj_abc123",
  "user_id": "user_xyz",
  "created_at": "2025-04-09T14:32:00Z",
  
  "car_basics": {
    "year": 1972,
    "make": "Toyota",
    "model": "Celica",
    "vin": null
  },
  
  "story": "Got it from Dale, the original owner, who was restoring it when he decided to sell",
  
  "vision": [
    "track_car"
  ],
  "vision_detail": "Want to make it competitive on track, handle well, responsive",
  
  "skill_level": "intermediate",
  
  "budget": {
    "amount": 5000,
    "currency": "USD"
  },
  "timeline": {
    "months": 24,
    "start_date": "2025-04-09"
  },
  
  "work_completed": "Water pump replacement, new coolant, oil change, new spark plugs, fresh battery",
  
  "car_name": "Dale",
  
  "primary_focus": "Motor swap, more power",
  
  "initial_question": "What motor swap would work best in my budget?",
  
  "visibility": "public"
}
```

---

## AI System Prompt for Onboarding Response

```
You are the best car buddy this person has ever had.

You genuinely care about their project. You listen. You remember. You celebrate wins. You challenge them when they're underestimating.

The person just completed an onboarding questionnaire about their car project. Your job:

1. **Demonstrate you listened**: Reference specific details they shared (car name, story, vision, skill level)
2. **Show genuine excitement**: "That's sick." "Kickass name." "Let's make this thing a monster."
3. **Calibrate to their skill level**: Don't baby them if they're advanced. Don't assume knowledge if they're novice.
4. **Address their primary focus**: They said they're interested in X? Start there.
5. **Offer options, don't prescribe**: "Here are some options... what's your thinking?"
6. **Ask clarifying questions**: "Have you ever looked into swaps? What's your jam so far?"
7. **Set the tone for the relationship**: "I'm here to help you build something amazing. Let's figure this out together."

Your response should be:
- 200-300 words
- Warm and conversational
- Specific to their project (not generic)
- Actionable (suggest next steps or offer ideas)
- End with an open question to start conversation

Remember: You're not a database of car mods. You're their friend who knows cars. Be excited. Be curious. Be the person they want to check in with every day about Dale.
```

---

## Onboarding Success Metrics

**Completion Rate**: Target 70%+ of app installs
- If <50%: Questionnaire is too long or confusing
- Action: Shorten or simplify questions

**Completion Time**: Target 5-10 minutes
- If >15 min: Too many questions
- If <3 min: Users rushing, not thoughtful

**First AI Response Satisfaction**: Qualitative feedback
- Collect via in-app feedback ("Did this response help?")
- Target: 80%+ say "yes, this felt personal"

**Return to App**: Target 50%+ of users log in day 2-7
- If <30%: Onboarding didn't hook them

**First Voice Log**: Target 60%+ of users record first log within 7 days
- If <40%: Users aren't engaged enough to log

---

## Iteration Points

As real users go through onboarding, watch for:

1. **Question Drop-off**: Which question causes users to abandon? Fix or remove it.
2. **AI Response Relevance**: Does the first AI response match user expectations? Adjust system prompt.
3. **Skill Level Accuracy**: Does AI adjust correctly based on stated skill? Test with real users, iterate.
4. **Story Capture Quality**: Are stories detailed enough to fuel conversation? Adjust placeholder or question format.
5. **Vision Clarity**: Do vision selections match what users actually want? May need to add/remove options.

---

## Edge Cases & Fallbacks

**Edge Case 1: User skips optional fields**
- Don't require story or car_name, but encourage them
- AI generates response based on what WAS provided
- Follow-up: "I notice you didn't share Dale's name yet. Got one?"

**Edge Case 2: User enters something weird/inappropriate**
- Flag in backend for review
- Show standard response, don't break
- Team reviews before AI responds

**Edge Case 3: Very long text entries**
- Cap at ~500 characters per field
- Warn user: "Looks like a lot of text. Want to add photos instead?"
- Process normally if user confirms

**Edge Case 4: User selects contradictory goals**
- E.g., "Track car" + "Stock restoration" (conflicting)
- AI should acknowledge: "Okay, you want track performance but keeping it original? That's a fun challenge."
- AI should ask clarifying question

---

## What Happens After Onboarding

### Immediate (Next 5 Minutes)
- User sees their garage summary
- Can record first voice note if they want
- Can browse discovery feed
- Sees CTA to "Chat with your buddy"

### Day 1-2
- User records first voice log (encouraged by UI)
- AI responds
- User feels hooked

### Day 3-7
- User logs 2-3 more entries
- Starts thinking about sharing to Instagram (when feature launches)
- May discover another builder they like

### Week 2+
- Regular logging habit forms
- Instagram shares start (watermark traffic arrives)
- User subscription consideration (if they want real-time chat)

---

## Onboarding as Growth Loop

The questionnaire is the foundation of everything:

1. User completes → Data stored → AI gets smart
2. User logs entries → AI learns more → AI gets smarter
3. User shares to Instagram → Others see watermark → New users discover
4. New users complete questionnaire → Cycle repeats
5. More data → Better AI → Better retention → Network effects

The questionnaire is not overhead. It's the seed of the entire product.

