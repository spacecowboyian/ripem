# RipEm MVP: Data Model & Database Schema
## Complete Information Architecture

---

## Overview

This document defines the complete data model for RipEm MVP. It covers:
- Entity relationships
- Database schema (tables, fields, indexes)
- Data flow through the system
- Query patterns for AI context retrieval
- Storage requirements and constraints

---

## Core Entities & Relationships

```
User
  └── Subscription (billing, feature access)
  └── Garage (collection of projects)
       └── Project (individual car)
            ├── Questionnaire Data (onboarding)
            ├── Log Entry (voice entry + transcript)
            │    ├── AI Response
            │    ├── Photos
            │    └── Instagram Post (if shared)
            ├── Conversation (AI chat history)
            ├── Goals (planned modifications)
            └── Settings (privacy, preferences)
  └── Discovery (subscriptions, likes, algorithm prefs)
```

---

## Database Schema

### Table: `users`

**Purpose**: Core user identity and authentication

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  auth_type ENUM('email', 'google', 'apple') NOT NULL,
  password_hash VARCHAR(255) NULLABLE, -- only if auth_type='email'
  display_name VARCHAR(100),
  avatar_url VARCHAR(500),
  bio TEXT NULLABLE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP NULLABLE, -- soft delete
  
  INDEX (email),
  INDEX (created_at)
);
```

---

### Table: `garages`

**Purpose**: User's collection of projects (their personal workspace)

```sql
CREATE TABLE garages (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  garage_name VARCHAR(100) NULLABLE, -- e.g., "My Garage", "Mike's Workshop"
  garage_description TEXT NULLABLE,
  is_public BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE(user_id), -- one garage per user
  INDEX (user_id),
  INDEX (is_public)
);
```

---

### Table: `projects`

**Purpose**: Individual car project with full metadata

```sql
CREATE TABLE projects (
  id UUID PRIMARY KEY,
  garage_id UUID NOT NULL REFERENCES garages(id) ON DELETE CASCADE,
  
  -- Car Basics
  year INT NOT NULL,
  make VARCHAR(50) NOT NULL,
  model VARCHAR(100) NOT NULL,
  vin VARCHAR(17) NULLABLE,
  car_name VARCHAR(100) NOT NULL, -- "Dale", "The Beast", etc.
  
  -- Story & Vision
  origin_story TEXT NULLABLE, -- "Got from Dale, original owner"
  vision JSONB NOT NULL, -- ["track_car", "custom_build"] (array of enums)
  vision_detail TEXT NULLABLE, -- User's explanation of vision
  
  -- Calibration
  skill_level ENUM('novice', 'intermediate', 'advanced', 'professional') NOT NULL,
  
  -- Budget & Timeline
  budget_amount DECIMAL(10, 2) NOT NULL, -- in USD
  timeline_months INT NOT NULL,
  timeline_start_date DATE NOT NULL,
  
  -- Current State
  work_completed TEXT NULLABLE, -- comma-separated or narrative
  primary_focus TEXT NULLABLE, -- "Motor swap, more power"
  
  -- Status
  is_public BOOLEAN DEFAULT TRUE,
  is_active BOOLEAN DEFAULT TRUE,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX (garage_id),
  INDEX (is_public),
  INDEX (created_at DESC),
  INDEX (year, make, model) -- for discovery feed filtering
);
```

---

### Table: `questionnaire_responses`

**Purpose**: Store raw onboarding questionnaire data for AI context

```sql
CREATE TABLE questionnaire_responses (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Complete structured data from onboarding
  response_json JSONB NOT NULL, -- stores entire questionnaire response
  
  -- Key fields extracted for quick access
  skill_level ENUM('novice', 'intermediate', 'advanced', 'professional'),
  vision_primary ENUM('track_car', 'street_driver', 'restoration', 'custom', 'restomod', 'offroad'),
  budget_amount DECIMAL(10, 2),
  timeline_months INT,
  car_name VARCHAR(100),
  
  -- For AI context retrieval
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE(project_id),
  INDEX (project_id)
);
```

---

### Table: `log_entries`

**Purpose**: Voice logs, transcripts, photos, and AI responses

```sql
CREATE TABLE log_entries (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Voice & Transcription
  voice_recording_url VARCHAR(500) NULLABLE, -- S3 URL
  voice_duration_seconds INT NULLABLE,
  transcript TEXT NOT NULL, -- Whisper output
  transcript_confidence FLOAT NULLABLE, -- 0.0-1.0
  
  -- Entry Metadata
  entry_title VARCHAR(200), -- auto-generated or user-provided
  entry_summary TEXT NULLABLE, -- AI-generated summary for quick reference
  
  -- AI Response
  ai_response TEXT NOT NULL,
  ai_response_tokens INT NULLABLE, -- track token usage for cost
  
  -- Photos
  photo_urls JSONB, -- ["s3://...", "s3://..."]
  
  -- Status
  is_public BOOLEAN DEFAULT TRUE,
  is_shared BOOLEAN DEFAULT FALSE,
  
  -- Engagement
  likes INT DEFAULT 0,
  shares INT DEFAULT 0,
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX (project_id),
  INDEX (created_at DESC),
  INDEX (is_public),
  FULLTEXT INDEX (transcript, ai_response) -- for search
);
```

---

### Table: `instagram_posts`

**Purpose**: Track Instagram shares and engagement

```sql
CREATE TABLE instagram_posts (
  id UUID PRIMARY KEY,
  log_entry_id UUID NOT NULL REFERENCES log_entries(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id),
  
  -- Instagram Data
  instagram_post_id VARCHAR(100) NULLABLE, -- Instagram's ID if successfully posted
  instagram_post_url VARCHAR(500) NULLABLE,
  caption_generated TEXT NOT NULL, -- What we generated
  caption_actual TEXT NULLABLE, -- What user actually posted (may have edited)
  
  -- Watermark
  watermark_text VARCHAR(100) NOT NULL, -- "RipEm.app/dale"
  watermark_url VARCHAR(500) NOT NULL, -- tracking link with params
  
  -- Status
  post_status ENUM('draft', 'scheduled', 'posted', 'failed') DEFAULT 'draft',
  posted_at TIMESTAMP NULLABLE,
  
  -- Engagement Tracking
  instagram_likes INT DEFAULT 0,
  instagram_comments INT DEFAULT 0,
  instagram_shares INT DEFAULT 0,
  watermark_clicks INT DEFAULT 0, -- tracked via link params
  
  -- Sync
  last_sync_at TIMESTAMP NULLABLE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX (project_id),
  INDEX (post_status),
  INDEX (posted_at DESC)
);
```

---

### Table: `ai_conversations`

**Purpose**: Full conversation history with AI per project

```sql
CREATE TABLE ai_conversations (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Conversation metadata
  conversation_title VARCHAR(200) NULLABLE, -- "Motor swap options", "Suspension questions"
  
  -- Messages (stored as JSONB array for flexibility)
  messages JSONB NOT NULL, -- [
                           --   {
                           --     "role": "user",
                           --     "content": "Should I swap the motor?",
                           --     "timestamp": "2025-04-09T14:00:00Z",
                           --     "source": "text" | "voice_log"
                           --   },
                           --   {
                           --     "role": "assistant",
                           --     "content": "Here are your options...",
                           --     "timestamp": "2025-04-09T14:05:00Z",
                           --     "tokens_used": 342
                           --   }
                           -- ]
  
  -- Context for AI
  context_summary TEXT NULLABLE, -- Quick summary of what this conversation is about
  
  -- Status
  is_active BOOLEAN DEFAULT TRUE,
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_message_at TIMESTAMP,
  
  INDEX (project_id),
  INDEX (last_message_at DESC),
  INDEX (is_active)
);
```

---

### Table: `goals`

**Purpose**: Planned modifications and future work

```sql
CREATE TABLE goals (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Goal Details
  goal_title VARCHAR(200) NOT NULL, -- "4A-GE Motor Swap"
  goal_description TEXT NULLABLE,
  goal_category ENUM('engine', 'suspension', 'brakes', 'interior', 'exterior', 'other') NOT NULL,
  
  -- Planning
  estimated_cost DECIMAL(10, 2) NULLABLE,
  estimated_duration_hours INT NULLABLE,
  priority INT DEFAULT 0, -- 0=low, 1=medium, 2=high
  
  -- Status
  status ENUM('planning', 'in_progress', 'completed', 'postponed') DEFAULT 'planning',
  target_completion_date DATE NULLABLE,
  
  -- AI Context
  ai_suggestions JSONB NULLABLE, -- ["Option 1: 4A-GE", "Option 2: 2ZZ-GE"]
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULLABLE,
  
  INDEX (project_id),
  INDEX (status),
  INDEX (priority DESC)
);
```

---

### Table: `subscriptions`

**Purpose**: User subscription status and billing

```sql
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Subscription Type
  subscription_type ENUM('free', 'chat_pro', 'shop') NOT NULL,
  
  -- For projects add-on
  extra_projects_count INT DEFAULT 0, -- additional projects beyond free tier
  
  -- Billing
  billing_cycle_start TIMESTAMP,
  billing_cycle_end TIMESTAMP,
  renewal_date TIMESTAMP NULLABLE,
  auto_renew BOOLEAN DEFAULT TRUE,
  
  -- Status
  status ENUM('active', 'paused', 'cancelled', 'past_due') DEFAULT 'active',
  
  -- Platform
  platform ENUM('ios', 'android', 'web') NOT NULL, -- where they subscribed
  app_receipt_data JSONB NULLABLE, -- Apple/Google receipt validation
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  cancelled_at TIMESTAMP NULLABLE,
  
  INDEX (user_id),
  INDEX (status),
  INDEX (renewal_date),
  UNIQUE(user_id) -- one active subscription per user
);
```

---

### Table: `discovery_feed`

**Purpose**: User preferences and subscription tracking for discovery feed

```sql
CREATE TABLE discovery_feed (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Subscribed Garages (people they follow)
  subscribed_garage_ids JSONB NOT NULL, -- [garage_id_1, garage_id_2, ...]
  
  -- Liked Entries
  liked_entry_ids JSONB NOT NULL, -- [log_entry_id_1, log_entry_id_2, ...]
  
  -- Algorithm Preferences
  preferred_car_types JSONB, -- ["1970s Celica", "Hondas", "Japanese cars"]
  preferred_project_types JSONB, -- ["track_car", "restoration"]
  
  -- Algorithm State
  last_feed_algorithm_run TIMESTAMP, -- when was feed last personalized
  algorithm_version VARCHAR(20), -- "v1", "v2", etc.
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE(user_id),
  INDEX (user_id)
);
```

---

### Table: `discovery_feed_items`

**Purpose**: Individual feed items for pagination

```sql
CREATE TABLE discovery_feed_items (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  log_entry_id UUID NOT NULL REFERENCES log_entries(id) ON DELETE CASCADE,
  
  -- Ranking
  feed_rank INT NOT NULL, -- 1, 2, 3... (position in feed)
  ranking_reason ENUM(
    'subscribed_garage',
    'similar_car_type',
    'similar_project_type',
    'popular_trending',
    'serendipitous'
  ) NOT NULL,
  
  -- Engagement Tracking
  shown_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  clicked_at TIMESTAMP NULLABLE,
  liked_at TIMESTAMP NULLABLE,
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX (user_id, feed_rank),
  INDEX (log_entry_id),
  INDEX (created_at DESC)
);
```

---

### Table: `analytics_events`

**Purpose**: Track user actions for metrics and optimization

```sql
CREATE TABLE analytics_events (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  
  -- Event Details
  event_type VARCHAR(100) NOT NULL, -- "voice_log_created", "share_instagram", "ai_chat_response", etc.
  event_data JSONB, -- flexible data per event type
  
  -- Context
  app_version VARCHAR(20),
  platform ENUM('ios', 'android', 'web') NOT NULL,
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX (user_id),
  INDEX (event_type),
  INDEX (created_at DESC)
);
```

---

### Table: `ai_token_usage`

**Purpose**: Track token consumption for cost management

```sql
CREATE TABLE ai_token_usage (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  project_id UUID NULLABLE REFERENCES projects(id),
  
  -- Token Data
  request_type ENUM(
    'onboarding_response',
    'log_ai_response',
    'instagram_caption',
    'chat_response',
    'real_time_chat'
  ) NOT NULL,
  
  input_tokens INT NOT NULL,
  output_tokens INT NOT NULL,
  total_tokens INT NOT NULL,
  
  -- Cost (calculated at time of use)
  estimated_cost_usd DECIMAL(10, 4),
  
  -- Timestamp
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX (user_id),
  INDEX (created_at DESC)
);
```

---

## Data Flow Diagrams

### Flow 1: Onboarding → AI Response

```
User completes questionnaire
        ↓
POST /api/garage/create
        ↓
Insert into projects table
Insert into questionnaire_responses table
        ↓
Query projects + questionnaire_responses
Build LLM prompt context
        ↓
Send to OpenRouter (via Claude)
        ↓
Receive AI first response
        ↓
Insert into ai_conversations table
        ↓
Return response to iOS app
        ↓
User sees: "Dale's a kickass name..."
```

### Flow 2: Voice Log → Transcription → AI Response

```
User records voice offline
        ↓
App stores locally (offline-first)
        ↓
User comes online
        ↓
POST /api/log/create with audio file
        ↓
Upload voice file to S3
        ↓
Send to Whisper API (OpenAI)
        ↓
Receive transcript
        ↓
Query projects + questionnaire_responses + previous log entries
Build LLM prompt with full context
        ↓
Send to OpenRouter
        ↓
Receive AI response
        ↓
Insert into log_entries table
Insert into ai_conversations table
Record token usage in ai_token_usage table
        ↓
Return to iOS app
        ↓
Show notification: "Your buddy has responded"
```

### Flow 3: Share to Instagram

```
User taps "Share to Instagram"
        ↓
Query log_entry + project data
        ↓
Build LLM prompt: "Create Instagram caption for this log entry"
Send to OpenRouter
        ↓
Receive caption
        ↓
Generate watermark URL with tracking params
        ↓
Insert into instagram_posts table (status='draft')
        ↓
Show user caption + preview
        ↓
User approves/edits
        ↓
POST to Instagram API
        ↓
Update instagram_posts status='posted'
        ↓
Return post URL to user
```

### Flow 4: Discovery Feed

```
User opens discovery tab
        ↓
Query discovery_feed table for user
        ↓
Get subscribed_garage_ids + algorithm_prefs
        ↓
Query log_entries matching criteria:
  - Recent entries (last 7 days)
  - Public projects only
  - Matching car types OR project types
  - High engagement (likes, shares)
        ↓
Rank using algorithm (v1):
  30% subscribed garages
  30% similar car type
  25% similar project type
  15% trending
        ↓
Paginate results (20 per page)
        ↓
Insert into discovery_feed_items table
        ↓
Return to app
        ↓
User scrolls through feed
```

---

## AI Context Retrieval Pattern

When AI needs to respond to a user, the backend builds a context object:

```javascript
const context = {
  user: {
    name: user.display_name,
    skill_level: questionnaire.skill_level,
    num_projects: user.project_count
  },
  
  project: {
    year: project.year,
    make: project.make,
    model: project.model,
    name: project.car_name,
    vision: project.vision,
    story: project.origin_story,
    work_completed: project.work_completed
  },
  
  questionnaire: questionnaire_responses.response_json,
  
  recent_entries: [
    { timestamp, transcript, ai_response },
    { timestamp, transcript, ai_response },
    ...
  ],
  
  conversation_history: ai_conversations.messages.slice(-10), // last 10 messages
  
  goals: goals.filter(g => g.status !== 'completed').slice(0, 5)
};

const llm_prompt = `
System: [Car Buddy System Prompt]

Context:
${JSON.stringify(context, null, 2)}

Current Request:
[User's current message/log/question]

Instructions:
1. Show you read their context
2. Be their car buddy
3. Give specific advice
`;
```

---

## Query Patterns

### Get Project's Full Brain

```sql
SELECT 
  p.*,
  qr.response_json,
  array_agg(le.id) as log_entry_ids,
  array_agg(le.created_at) as log_timestamps,
  count(le.id) as total_entries
FROM projects p
LEFT JOIN questionnaire_responses qr ON p.id = qr.project_id
LEFT JOIN log_entries le ON p.id = le.project_id
WHERE p.id = $1
GROUP BY p.id, qr.response_json;
```

### Get Recent Entries for AI Context

```sql
SELECT id, transcript, ai_response, created_at
FROM log_entries
WHERE project_id = $1
ORDER BY created_at DESC
LIMIT 5;
```

### Get Discovery Feed for User

```sql
SELECT 
  le.id, le.transcript, le.created_at,
  p.car_name, p.year, p.make, p.model,
  g.id as garage_id, u.display_name,
  COUNT(DISTINCT dfi.id) as ranking_score
FROM log_entries le
JOIN projects p ON le.project_id = p.id
JOIN garages g ON p.garage_id = g.id
JOIN users u ON g.user_id = u.id
LEFT JOIN discovery_feed_items dfi ON le.id = dfi.log_entry_id
WHERE p.is_public = TRUE
  AND le.is_public = TRUE
  AND le.created_at > NOW() - INTERVAL '7 days'
  AND (
    p.year = (SELECT preferred_car_year FROM discovery_feed WHERE user_id = $1)
    OR p.vision && (SELECT preferred_project_types FROM discovery_feed WHERE user_id = $1)
  )
GROUP BY le.id, p.id, g.id, u.id
ORDER BY ranking_score DESC
LIMIT 20;
```

---

## Storage & Performance Considerations

### Data Size Estimates (MVP, 10K users)

| Table | Est. Rows | Size |
|-------|-----------|------|
| users | 10,000 | 2 MB |
| garages | 10,000 | 1 MB |
| projects | 15,000 | 5 MB |
| log_entries | 100,000 | 500 MB |
| ai_conversations | 50,000 | 100 MB |
| instagram_posts | 50,000 | 25 MB |
| discovery_feed_items | 200,000 | 50 MB |
| analytics_events | 1,000,000 | 200 MB |

**Total: ~900 MB**

### Key Indexes

- `projects(garage_id)` - every AI context query needs this
- `log_entries(project_id, created_at DESC)` - frequent sorting
- `log_entries(is_public)` - discovery feed filtering
- `ai_conversations(project_id, last_message_at DESC)` - chat history
- `discovery_feed_items(user_id, feed_rank)` - feed pagination
- `ai_token_usage(created_at DESC)` - cost tracking

---

## Cost Management via Data

Track every LLM call:

```sql
INSERT INTO ai_token_usage (
  user_id, project_id, request_type,
  input_tokens, output_tokens, estimated_cost_usd
) VALUES (
  $1, $2, 'log_ai_response', 342, 156, 0.0248
);
```

Free tier users: Track token usage, throttle if abusing
Premium tier users: Show usage in dashboard, charge accordingly

---

## Migration Strategy

**MVP Launch** (Week 1):
- Deploy schema above
- Test with 100 internal users
- Iterate based on real data patterns

**Post-Launch** (Ongoing):
- Add vector embeddings for semantic search (future)
- Add read replicas for scale (if needed)
- Add partitioning on log_entries by date (if >10M rows)

---

## Questions for Database Team

1. Should `ai_conversations.messages` be a separate table for easier querying? (vs. JSONB array)
2. Do we need full-text search on transcripts? (FULLTEXT index vs. dedicated search service)
3. Should we use vector embeddings for semantic similarity (for discovery feed)?
4. How should we handle soft deletes vs. hard deletes for compliance?
5. What's the backup/disaster recovery strategy?

