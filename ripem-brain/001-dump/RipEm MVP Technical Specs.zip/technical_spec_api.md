# RipEm MVP: API Specification
## Complete REST API Contract

---

## Overview

This document defines all REST API endpoints for RipEm MVP. These endpoints power:
- iOS app (primary)
- Web app (secondary)
- Future integrations

**Base URL**: `https://api.ripem.app/v1`

**Authentication**: Bearer token (JWT) from OAuth or email/password login

---

## Authentication & Auth Endpoints

### POST /auth/register

**Purpose**: Create new user account via email/password

**Request**:
```json
{
  "email": "user@example.com",
  "password": "securepassword123",
  "display_name": "Mike"
}
```

**Response** (200):
```json
{
  "user_id": "user_abc123",
  "email": "user@example.com",
  "display_name": "Mike",
  "auth_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "refresh_xyz789"
}
```

**Error** (400):
```json
{
  "error": "email_already_exists"
}
```

---

### POST /auth/login

**Purpose**: Login with email/password

**Request**:
```json
{
  "email": "user@example.com",
  "password": "securepassword123"
}
```

**Response** (200):
```json
{
  "user_id": "user_abc123",
  "auth_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "refresh_xyz789",
  "expires_in": 3600
}
```

**Error** (401):
```json
{
  "error": "invalid_credentials"
}
```

---

### POST /auth/oauth/google

**Purpose**: Initiate Google OAuth flow

**Request**:
```json
{
  "id_token": "google_id_token_here"
}
```

**Response** (200):
```json
{
  "user_id": "user_abc123",
  "auth_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "is_new_user": false
}
```

---

### POST /auth/oauth/apple

**Purpose**: Initiate Apple OAuth flow

**Request**:
```json
{
  "identity_token": "apple_identity_token",
  "user_identifier": "user_id_from_apple"
}
```

**Response** (200): Same as Google OAuth

---

### POST /auth/refresh

**Purpose**: Refresh expired auth token

**Request**:
```json
{
  "refresh_token": "refresh_xyz789"
}
```

**Response** (200):
```json
{
  "auth_token": "new_auth_token_here",
  "expires_in": 3600
}
```

---

## Garage & Project Endpoints

### POST /garage/create

**Purpose**: Create user's garage (runs once per user, onboarding complete)

**Request**:
```json
{
  "garage_name": "Mike's Garage",
  "garage_description": "Tracking all my car projects"
}
```

**Response** (201):
```json
{
  "garage_id": "garage_abc123",
  "user_id": "user_xyz",
  "created_at": "2025-04-09T14:32:00Z"
}
```

---

### GET /garage/{garage_id}

**Purpose**: Get user's garage summary with all projects

**Response** (200):
```json
{
  "garage_id": "garage_abc123",
  "garage_name": "Mike's Garage",
  "user_id": "user_xyz",
  "projects": [
    {
      "project_id": "proj_abc123",
      "car_name": "Dale",
      "year": 1972,
      "make": "Toyota",
      "model": "Celica",
      "vision": ["track_car"],
      "total_entries": 12,
      "last_entry": "2025-04-08T16:45:00Z"
    },
    ...
  ]
}
```

---

### POST /project/create

**Purpose**: Create new car project (called during onboarding)

**Request**:
```json
{
  "garage_id": "garage_abc123",
  "year": 1972,
  "make": "Toyota",
  "model": "Celica",
  "car_name": "Dale",
  "origin_story": "Got it from Dale, the original owner",
  "vision": ["track_car"],
  "vision_detail": "Want to make it a fast track car",
  "skill_level": "intermediate",
  "budget_amount": 5000,
  "timeline_months": 24,
  "work_completed": "Water pump, coolant, oil change",
  "primary_focus": "Motor swap",
  "is_public": true
}
```

**Response** (201):
```json
{
  "project_id": "proj_abc123",
  "garage_id": "garage_abc123",
  "car_name": "Dale",
  "created_at": "2025-04-09T14:32:00Z"
}
```

---

### GET /project/{project_id}

**Purpose**: Get full project details

**Response** (200):
```json
{
  "project_id": "proj_abc123",
  "garage_id": "garage_abc123",
  "year": 1972,
  "make": "Toyota",
  "model": "Celica",
  "car_name": "Dale",
  "vision": ["track_car"],
  "skill_level": "intermediate",
  "budget_amount": 5000,
  "timeline_months": 24,
  "total_entries": 12,
  "goals": [
    {
      "goal_id": "goal_123",
      "goal_title": "4A-GE Motor Swap",
      "status": "planning",
      "priority": 2
    }
  ],
  "is_public": true,
  "created_at": "2025-04-09T14:32:00Z",
  "updated_at": "2025-04-08T16:45:00Z"
}
```

---

### PUT /project/{project_id}

**Purpose**: Update project details

**Request**:
```json
{
  "car_name": "Dale (Updated)",
  "vision": ["track_car", "restomod"],
  "work_completed": "...",
  "is_public": false
}
```

**Response** (200): Updated project object

---

### DELETE /project/{project_id}

**Purpose**: Delete project (soft delete)

**Response** (204): No content

---

## Log Entry Endpoints

### POST /log/create

**Purpose**: Create new voice log entry with transcription

**Request** (multipart/form-data):
```
voice_file: [binary audio file]
project_id: "proj_abc123"
photos: [file1.jpg, file2.jpg] (optional)
```

**Processing**:
1. Upload voice file to S3
2. Send to Whisper API for transcription
3. Build AI context from project + questionnaire
4. Send to OpenRouter for AI response
5. Store everything in database
6. Return response to user

**Response** (201):
```json
{
  "log_entry_id": "log_abc123",
  "project_id": "proj_abc123",
  "transcript": "Just installed a new exhaust on Dale, sounds amazing",
  "ai_response": "That's sick! New exhaust improves flow...",
  "voice_recording_url": "https://s3.amazonaws.com/...",
  "photo_urls": ["https://s3.amazonaws.com/..."],
  "created_at": "2025-04-09T14:32:00Z"
}
```

**Error** (400):
```json
{
  "error": "voice_file_required"
}
```

---

### GET /log/{log_entry_id}

**Purpose**: Get single log entry

**Response** (200):
```json
{
  "log_entry_id": "log_abc123",
  "project_id": "proj_abc123",
  "transcript": "Just installed a new exhaust...",
  "entry_title": "New Exhaust Installation",
  "ai_response": "That's sick! New exhaust improves flow...",
  "voice_recording_url": "https://s3.amazonaws.com/...",
  "photo_urls": ["https://s3.amazonaws.com/..."],
  "likes": 5,
  "shares": 2,
  "is_public": true,
  "created_at": "2025-04-09T14:32:00Z"
}
```

---

### GET /project/{project_id}/logs

**Purpose**: Get all logs for a project (paginated)

**Query Parameters**:
- `page` (default: 1)
- `limit` (default: 20, max: 100)
- `sort` (default: "created_at", options: "created_at", "likes", "shares")

**Response** (200):
```json
{
  "logs": [
    { log_entry_id, transcript, created_at, likes, shares },
    ...
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 47,
    "has_next": true
  }
}
```

---

### PUT /log/{log_entry_id}

**Purpose**: Update log entry (edit transcript, add photos, etc.)

**Request**:
```json
{
  "transcript": "Updated transcript",
  "photos": ["new_photo_1.jpg", "new_photo_2.jpg"]
}
```

**Response** (200): Updated log entry

---

### DELETE /log/{log_entry_id}

**Purpose**: Delete log entry

**Response** (204): No content

---

## AI Chat Endpoints

### POST /ai/chat

**Purpose**: Send message to AI, get response (async)

**Request**:
```json
{
  "project_id": "proj_abc123",
  "message": "Should I do a motor swap or just tune the current engine?",
  "message_type": "text" | "voice_transcript"
}
```

**Response** (201):
```json
{
  "conversation_id": "conv_abc123",
  "message_id": "msg_001",
  "status": "processing",
  "estimated_wait_seconds": 8
}
```

User polls for response (or uses WebSocket if real-time):

### GET /ai/chat/{conversation_id}/response

**Purpose**: Poll for AI response

**Response** (200) - not ready:
```json
{
  "status": "processing",
  "estimated_wait_seconds": 5
}
```

**Response** (200) - ready:
```json
{
  "status": "complete",
  "response": "Here are your options for motor swaps...",
  "response_tokens": 342
}
```

---

### GET /ai/chat/{project_id}/history

**Purpose**: Get conversation history for a project

**Query Parameters**:
- `limit` (default: 20)

**Response** (200):
```json
{
  "project_id": "proj_abc123",
  "conversations": [
    {
      "conversation_id": "conv_abc123",
      "title": "Motor Swap Discussion",
      "messages": [
        {
          "role": "user",
          "content": "Should I do a motor swap?",
          "timestamp": "2025-04-08T14:00:00Z"
        },
        {
          "role": "assistant",
          "content": "Here are your options...",
          "timestamp": "2025-04-08T14:05:00Z"
        }
      ]
    }
  ]
}
```

---

## Instagram Share Endpoints

### POST /share/instagram/preview

**Purpose**: Generate Instagram caption preview for log entry

**Request**:
```json
{
  "log_entry_id": "log_abc123",
  "project_id": "proj_abc123"
}
```

**Response** (200):
```json
{
  "caption": "Just upgraded Dale's exhaust. The sound is incredible. Can't wait to feel the difference on the track. 🏁\n\nTracking my build journey on RipEm, the app for car builders. [link]",
  "watermark_url": "https://ripem.app/dale?src=instagram&utm_campaign=...",
  "preview_image_url": "https://s3.amazonaws.com/preview.jpg"
}
```

---

### POST /share/instagram/publish

**Purpose**: Publish to Instagram

**Request**:
```json
{
  "log_entry_id": "log_abc123",
  "caption": "Just upgraded Dale's exhaust...", // user can edit
  "instagram_oauth_token": "instagram_access_token"
}
```

**Response** (201):
```json
{
  "instagram_post_id": "instagram_123456789",
  "instagram_post_url": "https://instagram.com/p/...",
  "watermark_clicks_tracking_url": "https://ripem.app/track/...",
  "posted_at": "2025-04-09T14:32:00Z"
}
```

---

### GET /share/instagram/{post_id}

**Purpose**: Get Instagram post metrics

**Response** (200):
```json
{
  "instagram_post_id": "instagram_123456789",
  "caption": "Just upgraded Dale's exhaust...",
  "posted_at": "2025-04-09T14:32:00Z",
  "engagement": {
    "likes": 24,
    "comments": 3,
    "shares": 1,
    "watermark_clicks": 5
  }
}
```

---

## Discovery Feed Endpoints

### GET /feed/discovery

**Purpose**: Get personalized discovery feed for user

**Query Parameters**:
- `page` (default: 1)
- `limit` (default: 20)

**Response** (200):
```json
{
  "feed_items": [
    {
      "log_entry_id": "log_xyz",
      "project_id": "proj_xyz",
      "car_name": "The Beast",
      "year": 1987,
      "make": "Chevrolet",
      "model": "Iroc-Z",
      "user_name": "John",
      "user_avatar": "https://...",
      "transcript_preview": "Just installed new headers, sounds incredible...",
      "likes": 12,
      "is_liked_by_current_user": false,
      "ranking_reason": "similar_car_type"
    },
    ...
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "has_next": true
  }
}
```

---

### POST /feed/subscribe

**Purpose**: Subscribe to another user's garage

**Request**:
```json
{
  "garage_id": "garage_xyz"
}
```

**Response** (201):
```json
{
  "subscription_id": "sub_abc123",
  "garage_id": "garage_xyz",
  "subscribed_at": "2025-04-09T14:32:00Z"
}
```

---

### DELETE /feed/subscribe/{garage_id}

**Purpose**: Unsubscribe from garage

**Response** (204): No content

---

### GET /feed/subscribed

**Purpose**: Get list of subscribed garages

**Response** (200):
```json
{
  "subscriptions": [
    {
      "garage_id": "garage_abc123",
      "user_name": "Mike",
      "user_avatar": "https://...",
      "num_projects": 3,
      "latest_activity": "2025-04-08T16:45:00Z"
    },
    ...
  ]
}
```

---

### POST /feed/like

**Purpose**: Like a log entry

**Request**:
```json
{
  "log_entry_id": "log_abc123"
}
```

**Response** (201):
```json
{
  "like_id": "like_xyz123",
  "log_entry_id": "log_abc123",
  "liked_at": "2025-04-09T14:32:00Z"
}
```

---

### DELETE /feed/like/{log_entry_id}

**Purpose**: Unlike a log entry

**Response** (204): No content

---

## Subscription Endpoints

### GET /subscription/status

**Purpose**: Get current subscription status

**Response** (200):
```json
{
  "subscription_type": "free" | "chat_pro" | "shop",
  "status": "active",
  "renewal_date": "2025-05-09",
  "features": {
    "extra_projects": 0,
    "chat_pro": false,
    "shop_tier": false,
    "unlimited_storage": false
  }
}
```

---

### POST /subscription/upgrade

**Purpose**: Initiate subscription upgrade (iOS In-App Purchase)

**Request**:
```json
{
  "subscription_type": "chat_pro",
  "app_receipt": "base64_encoded_receipt"
}
```

**Response** (201):
```json
{
  "subscription_id": "sub_abc123",
  "subscription_type": "chat_pro",
  "status": "active",
  "renewal_date": "2025-05-09"
}
```

---

## User Profile Endpoints

### GET /user/profile

**Purpose**: Get current user's profile

**Response** (200):
```json
{
  "user_id": "user_abc123",
  "email": "user@example.com",
  "display_name": "Mike",
  "avatar_url": "https://...",
  "bio": "Car enthusiast",
  "num_projects": 3,
  "num_followers": 12,
  "created_at": "2025-04-09T14:32:00Z"
}
```

---

### PUT /user/profile

**Purpose**: Update user profile

**Request**:
```json
{
  "display_name": "Mike Updated",
  "bio": "Celica enthusiast",
  "avatar_file": "file_upload"
}
```

**Response** (200): Updated profile

---

### POST /user/settings

**Purpose**: Update user settings

**Request**:
```json
{
  "notification_preferences": {
    "ai_responses": true,
    "new_followers": true,
    "discovery_recommendations": false
  },
  "privacy": {
    "profile_public": true,
    "show_projects_by_default": true
  }
}
```

**Response** (200): Updated settings

---

## Utility Endpoints

### GET /health

**Purpose**: Health check

**Response** (200):
```json
{
  "status": "healthy",
  "timestamp": "2025-04-09T14:32:00Z"
}
```

---

### POST /analytics/event

**Purpose**: Track user action (client-side)

**Request**:
```json
{
  "event_type": "voice_log_created",
  "event_data": {
    "project_id": "proj_abc123",
    "duration_seconds": 45
  },
  "platform": "ios",
  "app_version": "1.0.0"
}
```

**Response** (200):
```json
{
  "event_id": "evt_abc123",
  "recorded_at": "2025-04-09T14:32:00Z"
}
```

---

## Error Responses

All endpoints follow standard error format:

```json
{
  "error": "error_code",
  "message": "Human-readable error message",
  "details": {
    "field": "error_detail"
  }
}
```

### Common Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 204 | No Content |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 429 | Rate Limited |
| 500 | Server Error |

---

## Rate Limiting

- **Free tier**: 100 requests/hour
- **Chat Pro**: 500 requests/hour
- **Shop**: 5000 requests/hour

---

## Pagination

All list endpoints support pagination:
- `page` (default: 1)
- `limit` (default: 20, max: 100)

Response includes:
```json
{
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "has_next": true,
    "has_prev": false
  }
}
```

---

## Webhook Events (Future)

These are placeholder for post-MVP integrations:
- `log_entry.created`
- `instagram_post.published`
- `subscription.upgraded`
- `ai_response.completed`

