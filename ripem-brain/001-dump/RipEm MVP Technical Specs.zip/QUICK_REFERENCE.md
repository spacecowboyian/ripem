# RipEm MVP: Quick Reference for Agents
## What to Build, When, and Where to Find It

---

## TL;DR: The 2-Month Plan

**Week 1-2**: Build onboarding (questionnaire + first AI response)
**Week 3-4**: Build voice logging + AI chat
**Week 5-8**: Build Instagram sharing + discovery feed + subscription

---

## Phase 1: Onboarding (Weeks 1-2)

### What
- iOS screens 1-12 (questionnaire flow)
- Backend for questionnaire submission
- First AI response generation

### Where
- **Screens**: `technical_spec_onboarding_flow.md` → "Questionnaire Flow (iOS UX)"
- **Database**: `technical_spec_data_model.md` → tables: `users`, `garages`, `projects`, `questionnaire_responses`
- **API**: `technical_spec_api.md` → `/auth/register`, `/garage/create`, `/project/create`, `/ai/chat` (first response)
- **AI Behavior**: `technical_spec_core_architecture.md` → "The Car Buddy AI Personality"

### Success Metrics
- 70%+ questionnaire completion
- First AI response feels personal (not generic)
- User thinks: "This app gets me"

---

## Phase 2: Voice Logging (Weeks 3-4)

### What
- Voice recording UI (iOS)
- Whisper transcription integration
- AI response to voice logs
- Offline-first sync

### Where
- **iOS Code**: `technical_spec_ios_architecture.md` → RecordEntryView, AudioService, SyncService
- **Voice Pipeline**: `technical_spec_core_architecture.md` → "Voice → Transcription → AI Response Pipeline"
- **Database**: `technical_spec_data_model.md` → tables: `log_entries`, `ai_conversations`
- **API**: `technical_spec_api.md` → `/log/create`, `/ai/chat/{conversation_id}/response`

### Success Metrics
- Users record 3+ voice logs
- 99%+ sync reliability
- AI responses are contextual

---

## Phase 3: Social + Discovery (Weeks 5-8)

### What
- Instagram caption generation
- Instagram OAuth + publishing
- Discovery feed algorithm
- Subscription tiers

### Where
- **Instagram Integration**: `technical_spec_core_architecture.md` → "Instagram Integration"
- **API**: `technical_spec_api.md` → `/share/instagram/preview`, `/feed/discovery`, `/subscription/upgrade`
- **Database**: `technical_spec_data_model.md` → tables: `instagram_posts`, `discovery_feed`, `subscriptions`
- **Discovery Algorithm**: `technical_spec_core_architecture.md` → "Discovery Feed Algorithm (MVP Simple)"

### Success Metrics
- 1+ Instagram shares per active user
- 5-10% watermark click-through rate
- 3+ subscriptions per user in discovery feed

---

## Critical Documents by Role

### iOS Developer
1. **First**: `technical_spec_ios_architecture.md` (complete implementation guide)
2. **Then**: `technical_spec_api.md` (endpoints you'll call)
3. **Reference**: `technical_spec_onboarding_flow.md` (screens 1-12)

### Backend Developer
1. **First**: `technical_spec_core_architecture.md` (architecture overview)
2. **Then**: `technical_spec_data_model.md` (database schema)
3. **Then**: `technical_spec_api.md` (endpoints to build)
4. **Reference**: `technical_spec_onboarding_flow.md` (AI prompt)

### AI/LLM Engineer
1. **First**: `technical_spec_onboarding_flow.md` → "AI System Prompt for Onboarding Response"
2. **Then**: `technical_spec_core_architecture.md` → "The Car Buddy AI Personality"
3. **Reference**: `technical_spec_data_model.md` → "AI Context Retrieval Pattern"

### Product Manager / QA
1. **First**: `technical_spec_core_architecture.md` → "Phased Launch Timeline" + "Success Metrics"
2. **Then**: `TECHNICAL_SPECIFICATION_INDEX.md` → "Key Numbers for MVP"
3. **Reference**: Each phase document for acceptance criteria

---

## The Core Loop (Memorize This)

```
1. User answers questionnaire
   ↓
2. AI reads their garage brain, responds with understanding
   ↓
3. User logs voice entry about their car
   ↓
4. AI reads the entry + garage brain, responds helpfully
   ↓
5. User shares to Instagram with one tap
   ↓
6. Watermark drives others to discover RipEm
   ↓
7. Others create garages, log entries, share
   ↓
8. More content = better algorithm = more growth
```

---

## The Car Buddy Personality (Memorize This)

The AI should:
- ✅ **Listen**: Read their entire garage history before responding
- ✅ **Celebrate**: "That's sick, I'm adding that to the history"
- ✅ **Understand**: Know their skill level, budget, timeline
- ✅ **Suggest, Not Prescribe**: "Here are options... what's your thinking?"
- ✅ **Ask Follow-Ups**: "Have you ever considered...?"
- ✅ **Motivate**: "Let's make this thing a monster"
- ✅ **Be Their Friend**: "I'm here to help you build something amazing"

If the AI sounds like ChatGPT, it's wrong. If it sounds like a friend who cares about their car, it's right.

---

## Quick Schema Reference

### Minimum Tables Needed
```
users              (id, email, auth_token, created_at)
garages            (id, user_id, created_at)
projects           (id, garage_id, year, make, model, car_name, skill_level, budget, vision)
questionnaire_responses (id, project_id, response_json)
log_entries        (id, project_id, transcript, ai_response, created_at, sync_status)
ai_conversations   (id, project_id, messages JSONB, created_at)
subscriptions      (id, user_id, subscription_type, status)
```

### Minimum API Endpoints
```
Auth:
  POST /auth/register
  POST /auth/login

Garage/Project:
  POST /garage/create
  POST /project/create
  GET /project/{id}

Logging:
  POST /log/create (voice file + photos)
  GET /log/{id}

AI:
  POST /ai/chat (send message, returns async response)
  GET /ai/chat/{conversation_id}/response (poll for response)

Instagram:
  POST /share/instagram/publish

Discovery:
  GET /feed/discovery
  POST /feed/subscribe
```

---

## Token Cost Management

**Free Tier**: 
- Onboarding AI response: ~1000 tokens
- Per voice log: ~500 tokens input + ~400 tokens response
- Per Instagram caption: ~300 tokens

**Limit to**: ~10 logs per user per month (free tier)

**Premium Tier (Chat Pro)**:
- Unlimited logs
- Real-time chat (streaming)
- Direct LLM access

**Track every call**: Insert into `ai_token_usage` table

---

## Testing Checklist

### Phase 1 (Onboarding)
- [ ] All 12 questions display correctly
- [ ] User can skip optional fields
- [ ] Questionnaire completion takes <10 minutes
- [ ] First AI response appears within 5 seconds
- [ ] First response mentions car name + story + vision

### Phase 2 (Voice Logging)
- [ ] Can record voice offline
- [ ] Sync happens when online
- [ ] Transcription is accurate
- [ ] AI response reads previous logs (context)
- [ ] Notifications work

### Phase 3 (Instagram + Discovery)
- [ ] Instagram caption is well-written
- [ ] One-click publish works
- [ ] Watermark is visible on post
- [ ] Watermark URL is clickable
- [ ] New users arrive via watermark
- [ ] Discovery feed shows relevant cars

---

## Common Questions

**Q: What if the questionnaire is too long and users drop off?**
A: Test with 8 questions vs. 12. Track completion rate. Adjust questions to the most important 8.

**Q: What if Whisper transcription is slow?**
A: Queue transcription jobs, show "Transcribing... (usually <5s)" state. Don't block UI.

**Q: What if AI responses are generic?**
A: Iterate on system prompt. Test with real car enthusiasts. Ask them: "Does this feel like a friend?"

**Q: What if Instagram API rejects us?**
A: Apply early, explain use case, follow rate limits. Have a fallback: copy-to-clipboard.

**Q: What if OpenRouter tokens cost too much?**
A: Cap free tier at 10 logs/month. Premium tier is $5-7/month. Ads cover free tier costs.

**Q: What if we launch and MotorMia adds voice the same week?**
A: That's fine. We're not competing on parts recommendations. We're competing on story + content + community.

---

## Deployment Checklist

### Pre-Launch (Week 7)
- [ ] All code reviewed and tested
- [ ] Database migrations tested on staging
- [ ] API rate limiting configured
- [ ] Whisper API quota set up
- [ ] Instagram OAuth approved
- [ ] S3 buckets configured
- [ ] Analytics events are logging
- [ ] Error handling is robust

### Launch Day (Week 8)
- [ ] TestFlight beta with 100 users
- [ ] Monitor crash rates
- [ ] Monitor sync failures
- [ ] Monitor AI response quality
- [ ] Monitor onboarding completion
- [ ] Be ready to roll back

---

## Post-Launch Priorities (Week 9+)

1. **Iterate onboarding** based on drop-off data
2. **Improve AI responses** based on user feedback
3. **Scale infrastructure** if traffic grows
4. **Add real-time chat** (if demand is high)
5. **Add web app** (if iOS is successful)
6. **Approach MotorMia** with partnership proposal (if growth is strong)

---

## Emergency Contacts / Questions

If you're stuck:
1. Re-read the relevant spec document
2. Check "Questions for Agents" section at end of relevant doc
3. Check "Known Unknowns" section in Core Architecture doc
4. Flag it for the team to discuss

---

## Final Reminder

**This is aggressive, but doable.**

2 months to MVP means:
- Focus on the core loop (questionnaire → logging → sharing)
- Don't build features that aren't in the timeline
- Iterate on what matters (onboarding, AI quality, sync reliability)
- Launch with something great, not something perfect

The goal isn't to have everything—it's to have the thing that makes people say "This is different. This is my car buddy."

**Good luck. Build it. 🚗**

