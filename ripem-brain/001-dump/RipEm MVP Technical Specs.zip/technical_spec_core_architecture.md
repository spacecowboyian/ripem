# RipEm MVP Technical Specification
## Core Architecture Overview

**Version**: 1.0  
**Date**: April 2025  
**Status**: Ready for Agent Ingestion  
**Timeline**: 2-Month Phased Launch  

---

## Executive Summary

RipEm's MVP is built around a single core insight: **The AI Garage Buddy** — an always-on car friend who knows your project instantly, cares about your progress, and helps you build something great.

This spec defines the technical architecture to make that magic happen, broken into a phased 8-week launch:
- **Weeks 1-4**: Onboarding + AI Garage Brain + Voice Logging
- **Weeks 5-6**: Instagram Auto-Publishing with Watermark
- **Weeks 7-8**: Discovery Feed + Algorithm

---

## Core Product Promise

When a user opens RipEm for the first time, they will:

1. **Answer a guided questionnaire** about their car project (story, vision, skill level, budget)
2. **Meet their AI buddy** who demonstrates instant knowledge of their project and genuine interest
3. **Voice-log their first entry** and get an AI response that shows understanding of their context
4. **Share their progress** to Instagram with a beautiful caption (auto-generated, watermarked)
5. **Discover others' projects** in a feed and subscribe to builds they care about

By Day 7, the user has:
- Logged 3-5 project entries via voice
- Had conversations with their AI about motor swaps, suspension, budget, timeline
- Shared 1-2 posts to Instagram with watermark
- Subscribed to 2-3 other garages in the discovery feed

---

## Architecture Principles

1. **Garage-First Everything** - Every interaction starts with the user's project data (garage brain)
2. **Async-First, Real-Time Later** - MVP is non-real-time chat; real-time is premium feature
3. **Data-as-Moat** - Every log entry, question, and preference trains future proprietary model
4. **Zero Friction on Entry** - Voice first, guided questionnaire, not forms
5. **Social by Default** - Public builds, watermarks, discovery feed drive growth
6. **Freemium from Day 1** - Free tier is powerful enough to be useful; premium unlocks async limits + real-time chat

---

## High-Level Technical Stack

### Frontend
- **iOS**: Native Swift (primary MVP platform)
- **Web**: React/TypeScript (secondary, for web access to garage + AI chat)
- **Offline-First**: Local recording/logging, sync when online

### Backend
- **API**: REST (agents to decide framework: Node.js, Python, etc.)
- **Database**: TBD by agents (must be AI-friendly: PostgreSQL, vector-enabled)
- **Storage**: AWS S3 for photos/media
- **Voice**: Whisper API (OpenAI) for transcription
- **LLM**: OpenRouter (all LLM calls go through here)

### Infrastructure
- **Hosting**: Agents to decide (Vercel mentioned as standard)
- **Authentication**: OAuth (Google, Apple) + Email/Password
- **Analytics**: Trackable events (onboarding completion, log entries, shares, AI responses)

---

## Core Data Model (Simplified)

```
User
├── garage (their collection of projects)
│   ├── Project (car)
│   │   ├── metadata (year, make, model, name, story)
│   │   ├── vision (track car, restoration, daily driver, etc.)
│   │   ├── skill_level (novice, intermediate, advanced)
│   │   ├── budget & timeline
│   │   ├── completed_work (history)
│   │   ├── log_entries (voice-to-text logs)
│   │   │   ├── transcript
│   │   │   ├── timestamp
│   │   │   ├── photos
│   │   │   ├── ai_response
│   │   │   └── instagram_post (if shared)
│   │   └── goals (planned modifications)
│   └── Settings
│       ├── subscription_level
│       └── privacy (public/private)
├── subscriptions
│   ├── chat_pro (real-time chat)
│   ├── projects (additional projects beyond free tier)
│   └── shop (multi-user workspace)
└── discovery_feed_prefs
    ├── subscribed_garages
    └── liked_entries
```

---

## Phased Launch Timeline

### Phase 1: Weeks 1-4 (ONBOARDING + AI GARAGE BRAIN)

**What Ships**:
- iOS app (TestFlight beta or direct download)
- Onboarding questionnaire flow
- Garage knowledge base creation
- First AI interaction (the "Dale moment")
- Voice recording capability (no transcription yet)

**What Doesn't Ship Yet**:
- Instagram publishing
- Discovery feed
- Web app

**User Flow**:
1. Download app
2. Answer questionnaire (car details, story, vision, skill level)
3. AI responds with personalized greeting
4. User can record voice notes (stored locally)
5. User can view their garage summary

**Why This Works**:
- Proves the core magic in 4 weeks
- Sets up all future features
- Gets feedback on questionnaire quality
- Users feel understood immediately

---

### Phase 2: Weeks 5-6 (AI VOICE LOGGING + RESPONSES)

**What Adds**:
- Whisper transcription integration
- Voice → Transcription → AI Response pipeline
- Async chat responses (notifications when ready)
- Offline sync capability
- Log entry view with AI suggestions

**What Still Doesn't Ship**:
- Instagram publishing
- Discovery feed

**User Flow**:
1. User records: "Just replaced the thermostat, car runs cooler now"
2. App shows: "Recording offline..."
3. User goes online
4. App: "Syncing..."
5. Whisper transcribes
6. AI reads garage brain + transcript
7. AI responds: "Nice, thermostat upgrade improves cooling. Since you're doing maintenance work, have you thought about water pump? It's on the same cooling circuit and typically goes around the same time..."
8. User sees response in-app (notification if not open)

**Why This Works**:
- Core loop is now functional
- Users have real conversations with their AI
- Sets up Instagram data in Week 5-6

---

### Phase 3: Weeks 7-8 (INSTAGRAM + DISCOVERY FEED)

**What Adds**:
- Instagram auto-publishing
- AI caption generation from log entries
- Watermark on posts (with app URL)
- Discovery feed (browse other garages)
- Simple algorithm (car type, interests, subscriptions)

**What's Ready**:
- Full iOS app
- Full onboarding + AI + logging
- Social sharing loop

**User Flow**:
1. User logs entry: "Just installed new exhaust, sounds insane"
2. AI responds with suggestions
3. User taps "Share to Instagram"
4. App auto-generates caption: "Just upgraded Dale's exhaust. The sound is incredible. Can't wait to feel the difference on the track. 🏁 Tracking my build journey on RipEm, the app for car builders. [link with watermark]"
5. User approves/edits
6. One-click publish to Instagram
7. Watermark drives others to discover feed in RipEm

**Why This Works**:
- Growth loop is now active
- Users become RipEm ambassadors
- Watermark traffic validates concept
- Discovery feed gives new users content to scroll

---

## The "Car Buddy" AI Personality

### System Prompt Foundation

The AI's behavior is driven by a custom system prompt that instructs it to:

**Listen**: Read the entire garage history before responding. Remember every detail.

**Celebrate**: "That's sick. I'm adding that to the history." Show genuine excitement about their project.

**Understand Context**: Recognize their skill level, budget, timeline. Calibrate advice accordingly.

**Suggest, Don't Prescribe**: "I've got some ideas... what's your thinking?" Not "You must do X."

**Ask Follow-Ups**: "Have you ever heard about motor swaps? What's your jam so far?"

**Motivate**: "Let's make this thing a monster." Remind them to get in the garage.

**Build Relationship**: Be their car friend. The one who actually gives a shit.

### Example First Response (Post-Onboarding)

User completes questionnaire:
- Car: 1972 Toyota Celica
- Vision: Track car build
- Skill: Intermediate (replaced water pump, changed fluids)
- Budget: $5K over 2 years
- Named: "Dale" (after original owner)

AI Response:

> "Dale's a kickass name. So the original owner was Dale? That's sick, I'm adding that to the history.
>
> Okay, so you've got a classic Celica track car project. 1972 is the perfect year for this—solid platform. Based on what you've shared, I can see you've got mechanical chops (water pump + fluids = you know how to work). Here's what I'm thinking:
>
> With a $5K budget over 2 years and track car ambitions, the limiting factor is going to be power. The stock 18R-C motor is... not a monster. There are some killer motor swap options for a 72 Celica that people have done successfully. Have you ever looked into swaps? What's your thinking—are you trying to keep it period-correct, or are you willing to go with something modern?
>
> Either way, let's make this thing a real monster. I'm here to help you figure it out."

---

## API & Backend Requirements

### Core Endpoints (Minimal MVP)

```
POST /api/auth/login (OAuth + Email)
POST /api/auth/register

POST /api/garage/create (new user questionnaire submission)
GET /api/garage/{userId} (read garage data)
PUT /api/garage/{userId} (update garage)

POST /api/log/create (voice log entry)
GET /api/log/{projectId} (read entries)

POST /api/ai/chat (send user message/log, get AI response)
GET /api/ai/chat/{projectId} (conversation history)

POST /api/share/instagram (publish to Instagram)
GET /api/discovery-feed (get feed items)
POST /api/subscription/toggle (subscribe to garage)
```

### Database Tables

- `users` (id, email, auth_type, created_at)
- `garages` (user_id, public/private, created_at)
- `projects` (garage_id, name, year, make, model, vision, skill_level, budget, timeline, questionnaire_data)
- `log_entries` (project_id, transcript, photos_url[], timestamp, ai_response, instagram_post_id)
- `ai_conversations` (project_id, messages[], created_at)
- `subscriptions` (user_id, subscription_type, level, status, renewal_date)
- `discovery_feed` (user_id, subscribed_projects[], algorithm_preferences)

---

## Voice → Transcription → AI Response Pipeline

### Flow Diagram

```
User records voice → App stores locally
                  ↓
            User goes online
                  ↓
            Sync triggers
                  ↓
        Send to Whisper API
                  ↓
        Receive transcription
                  ↓
        Query garage knowledge base
                  ↓
        Build LLM prompt:
        - System prompt (car buddy)
        - Garage history
        - Project context
        - Transcript
                  ↓
        Send to OpenRouter
                  ↓
        Receive AI response
                  ↓
        Store in database
                  ↓
        Show to user (notification if app closed)
```

### LLM Prompt Structure

```
System: [Car Buddy Personality Prompt]

Context:
- User: [name]
- Project: [car details]
- Skill Level: [level]
- Budget/Timeline: [X/$Y over Z months]
- Previous Entries: [last 5 log summaries]
- Previous AI Responses: [last 3 responses for consistency]

Current Entry Transcript:
"[user's voice-to-text entry]"

Instructions:
1. Demonstrate you read their garage history
2. Show understanding of their specific situation
3. Ask clarifying questions or suggest next steps
4. Maintain the car buddy personality
5. Keep response to 150-250 words
```

---

## Instagram Integration

### What Happens

User logs entry → Taps "Share to Instagram" → AI generates caption → User approves → Posts with watermark

### Watermark Design

```
[Instagram Photo with Caption]

"Just upgraded Dale's exhaust. The sound is incredible. 
Can't wait to feel the difference on the track. 🏁

Tracking my build journey on RipEm.
The AI garage buddy for your car project.
[QR Code or Link: ripem.app/dale]"
```

### Why This Works

- Caption is AI-written (good English, storytelling)
- Watermark is subtle (not obnoxious)
- QR/Link is clickable
- Others see it → curiosity → try RipEm
- Algorithm feeds them relevant builds (similar cars)
- They sign up if it's useful

---

## Discovery Feed Algorithm (MVP Simple)

### V1 Algorithm

```
For each user, show builds where:
1. Car type matches their subscribed vehicles (30%)
2. Car type matches their interests from questionnaire (30%)
3. Popular/trending builds (top engagements) (25%)
4. Random/serendipitous (other car projects) (15%)

Ranking:
- Newer entries rank higher
- Entries with more likes/shares rank higher
- Entries from subscribed garages appear first
```

### Engagement Metrics

- Likes (user can like an entry)
- Subscriptions (user can subscribe to a garage)
- Shares (user can share a friend's entry)

These feed the algorithm over time.

---

## Subscription Model (MVP Launch)

### Free Tier
- 1 free project
- Unlimited log entries on that project
- Async AI responses (may wait 5-60 seconds)
- Offline recording + sync
- Discovery feed
- Share to Instagram (with watermark)
- Ads shown

### Chat Pro - $5-7/month
- Everything in Free
- Real-time voice chat (stretch goal, demo-able)
- Ad-free experience
- iOS/Android in-app subscription

### Projects Expansion - $2/month per additional project
- Each new project beyond the 1 free
- Stacks with other subscriptions

### Shop Tier - $20-50/month
- Unlimited projects
- Multi-user workspace (multiple mechanics/shop staff)
- Higher storage limits
- No ads
- Premium support

---

## What Requires OpenRouter (Cost Center)

1. **Questionnaire AI Review** - AI reads answers, generates personalized greeting (1 call per user)
2. **Voice Log AI Responses** - Every voice log triggers an AI response (1 call per log)
3. **Instagram Caption Generation** - Auto-write captions for shared posts (1 call per share)
4. **Real-Time Chat** (Premium) - Streaming responses for paid users

### Cost Management Strategy

- Free tier: Async chat only (batched, cheaper)
- Premium: Real-time chat (individual calls, higher cost)
- User sees cost before subscribing
- Ads cover free tier costs
- Shop tier pays directly for agent usage

---

## Security & Privacy

### MVP Requirements

- HTTPS only
- OAuth tokens stored securely
- User passwords hashed (bcrypt)
- S3 presigned URLs for photo upload (no direct access)
- Rate limiting on API endpoints (prevent abuse)
- GDPR-compliant data deletion (users can delete garage)
- User data is private by default; builds are public unless toggled

### Not MVP

- End-to-end encryption (can add later)
- Two-factor authentication (can add later)
- Advanced privacy controls (can add later)

---

## Success Metrics (MVP Launch)

**Week 1-4 (Onboarding Phase)**:
- Questionnaire completion rate target: 70%+
- First AI response satisfaction: Qualitative feedback
- Time to first voice log: avg <5 min
- Retention to Day 7: 50%+ of signups

**Week 5-6 (Voice Logging Phase)**:
- Voice logs per active user: avg 3+
- AI response satisfaction: Qualitative + NPS
- Sync reliability: 99%+ success
- Offline recording usage: 30%+ of logs

**Week 7-8 (Social Phase)**:
- Instagram shares per active user: avg 1+
- Watermark click-through rate: target 5-10%
- Discovery feed engagement: avg 3+ subscriptions per user
- New user acquisition from watermark: track URL parameter

---

## Known Unknowns / Test-as-You-Go

1. **Questionnaire length** - How long should it be? Test with 5-10 minute vs. 10-15 minute versions
2. **AI personality consistency** - Does the car buddy feel natural? Gather feedback, adjust system prompt
3. **Offline sync reliability** - Does it work smoothly? May need to iterate on sync logic
4. **Instagram algorithm** - Do watermarked posts get engagement? May need to adjust caption strategy
5. **Discovery feed algorithm** - Does it show relevant builds? Iterate based on user feedback
6. **Subscription conversion** - What percentage convert to paid? May need to adjust price or features

---

## What's NOT in MVP

- Real-time voice chat (premium stretch goal)
- Video generation (Phase 2)
- TikTok/YouTube Shorts publishing (Phase 2)
- Web app fully featured (Phase 2)
- Advanced analytics dashboard (Phase 3)
- Mechanics certification program (Phase 3)
- Shop inventory management (Phase 3)
- Parts affiliate marketplace (Phase 3)

---

## Next Steps

1. **Data Model Finalization** - Lock in schema with agents
2. **Onboarding Flow Design** - Questionnaire UX needs to be perfect
3. **System Prompt Engineering** - Test car buddy personality
4. **API Contract Definition** - Frontend/backend teams align
5. **Voice Pipeline Testing** - Whisper API → transcription → AI response
6. **Instagram Integration** - Test OAuth, posting, watermark rendering
7. **iOS App Development** - Begin build with TestFlight beta target for Week 4
8. **Backend API Development** - Begin parallel with iOS

---

## Questions for Agents

1. What database structure best supports vector searches (for AI context retrieval)?
2. How should offline sync handle conflicts (user edits locally, AI response comes in)?
3. What's the best way to structure the "garage brain" for fast LLM context inclusion?
4. How do we prevent token costs from spiraling if one user logs 50 entries in a day?
5. What's the Instagram API flow for OAuth + posting programmatically?

